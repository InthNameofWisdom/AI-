# -*- coding: utf-8 -*-
"""
最小 TTS 假服务器（仅用于开发自测，演示时不要用）
================================================
作用：在没有安装 GPT-SoVITS 的机器上，验证**真实的客户端代码路径**。

它刻意复刻了真实 GPT-SoVITS 服务器的两个行为，所以能测出「只有在真服务器上
才会犯的错」，而不是只测通一条被简化过的路径：

  1. audio_url 里的 host 写成 0.0.0.0 —— 逼客户端必须「只取文件名、用配置的
     base_url 重新拼」才能下载成功。直接拿 audio_url 当下载地址的代码会挂。
  2. text_lang / prompt_text_lang / emotion 三个字段缺任意一个，**不报错**，
     只返回一个 audio_url 为空的结果 —— 复刻那个最阴的坑。

用法：
    python tts_server_mock.py
    # 另开终端跑后端；config.yaml 里 tts.base_url 保持 http://127.0.0.1:8000 即可
"""
from __future__ import annotations

import asyncio
import hashlib
import io
import math
import struct
import wave

import uvicorn
from fastapi import FastAPI
from fastapi.responses import JSONResponse, Response

app = FastAPI(title="tts-server-mock")

SAMPLE_RATE = 16000
DEFAULT_PORT = 8000

# 合成过的音频：文件名 -> wav 字节
_OUTPUTS: dict[str, bytes] = {}


def _tone_wav(duration: float, freq: float = 440.0) -> bytes:
    """生成一段带淡入淡出的正弦提示音。

    用标准库 wave + struct 手搓，不引入 numpy 之类的额外依赖。
    时长跟文本长度挂钩，听感上接近「这句话有多长」。
    """
    total = max(1, int(duration * SAMPLE_RATE))
    fade = max(1, int(SAMPLE_RATE * 0.02))  # 20ms 淡入淡出，避免爆音

    frames = bytearray()
    for i in range(total):
        envelope = min(1.0, i / fade, (total - i) / fade)
        value = int(9000 * envelope * math.sin(2 * math.pi * freq * i / SAMPLE_RATE))
        frames += struct.pack("<h", value)

    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SAMPLE_RATE)
        w.writeframes(bytes(frames))
    return buf.getvalue()


@app.get("/version")
async def version() -> dict:
    return {"version": "mock-v4", "server": "tts_server_mock"}


@app.get("/models/{ver}")
async def models(ver: str) -> dict:
    return {"version": ver, "models": ["原神-中文-纳西妲_ZH", "mock-voice"]}


@app.post("/infer_single")
async def infer_single(payload: dict) -> dict:
    text = str(payload.get("text") or "")
    text_lang = payload.get("text_lang")
    prompt_text_lang = payload.get("prompt_text_lang")
    emotion = payload.get("emotion")

    # 复刻真实服务的坑：三件套缺一个就静默返回空 audio_url，不抛错
    if not (text_lang and prompt_text_lang and emotion):
        return {
            "audio_url": "",
            "message": "参数错误（text_lang / prompt_text_lang / emotion 必须同时非空）",
        }

    duration = max(0.4, 0.09 * len(text))
    filename = hashlib.md5(
        f"{text}|{text_lang}|{prompt_text_lang}|{emotion}".encode("utf-8")
    ).hexdigest() + ".wav"

    # 阻塞函数丢到线程池，别卡住事件循环 —— 否则 mock 自己就先串行化了，
    # 测不出「并发预取」到底有没有生效。
    _OUTPUTS[filename] = await asyncio.to_thread(_tone_wav, duration)

    return {
        # 故意写成 0.0.0.0：真实服务就是这个样子，用来验证客户端有没有
        # 老老实实只取文件名再重拼地址。
        "audio_url": f"http://0.0.0.0:{DEFAULT_PORT}/outputs/{filename}",
        "result_path": filename,
    }


@app.get("/outputs/{filename}")
async def outputs(filename: str) -> Response:
    data = _OUTPUTS.get(filename)
    if data is None:
        return JSONResponse({"detail": "not found"}, status_code=404)
    return Response(content=data, media_type="audio/wav")


if __name__ == "__main__":
    print(f"[mock] TTS 假服务器启动：http://127.0.0.1:{DEFAULT_PORT}")
    print("[mock] 记得演示前换回真实的 GPT-SoVITS")
    uvicorn.run(app, host="127.0.0.1", port=DEFAULT_PORT, log_level="warning")
