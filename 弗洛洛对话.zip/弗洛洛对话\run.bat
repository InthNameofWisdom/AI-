@echo off
REM ===================================================================
REM  Frolova Chat - launcher / portable first-run bootstrap
REM
REM  Usage:
REM    run.bat                  build the venv if needed, start, open browser
REM    run.bat --check-only     do everything except starting the server
REM    run.bat --no-browser     start it but do not open a browser
REM
REM  ------------------------------------------------------------------
REM  NOTE: this file is deliberately pure ASCII - do NOT add Chinese
REM  or any other multi-byte text, not even in REM lines. cmd reads a
REM  .bat by BYTE OFFSET line by line, so multi-byte characters shift
REM  the offsets and get executed as commands. chcp 65001 does not fix
REM  it. Chinese notes belong in README.md.
REM  ------------------------------------------------------------------
setlocal EnableExtensions
cd /d "%~dp0"
title Frolova chat launcher

set "CHECKONLY="
set "NOBROWSER="
for %%a in (%*) do (
  if /i "%%a"=="--check-only" set "CHECKONLY=1"
  if /i "%%a"=="--no-browser" set "NOBROWSER=1"
)

REM --- port: read it from config.yaml so the two never drift apart ---
set "PORT=8770"
for /f "tokens=2" %%p in ('findstr /r /c:"^  port:" config.yaml 2^>nul') do set "PORT=%%p"

echo.
echo ============================================================
echo   Frolova Chat   (port %PORT%)
echo ============================================================
echo.

REM ===============================================================
REM 1/4  Python + virtual environment
REM ===============================================================
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY goto :no_python

REM Reject an old interpreter, and the Microsoft Store placeholder
REM (which is not a real Python and prints a store advert instead).
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 7)" >nul 2>nul
if errorlevel 7 goto :old_python
if errorlevel 1 goto :bad_python

set "VENV_PY=%~dp0venv\Scripts\python.exe"

REM A venv is tied to the Python that created it - it records an absolute
REM path back to its base interpreter. So a folder copied from another PC
REM usually has a venv that cannot start at all. Detect that and rebuild.
if exist "%VENV_PY%" (
  "%VENV_PY%" -c "import sys" >nul 2>nul
  if errorlevel 1 (
    echo [1/4] The existing venv does not run on this machine.
    echo       Usually that means this folder was copied from another PC
    echo       ^(a venv points back at the Python that created it^).
    echo       Rebuilding it...
    rmdir /s /q "%~dp0venv" 2>nul
  )
)

if not exist "%VENV_PY%" (
  echo [1/4] Creating virtual environment...
  %PY% -m venv venv
  if errorlevel 1 goto :venv_failed
) else (
  echo [1/4] Virtual environment OK.
)

REM ===============================================================
REM 2/4  Dependencies
REM ===============================================================
if not exist "%~dp0venv\.deps-ok" (
  echo [2/4] Installing dependencies ^(first run only, needs network^)...
  "%VENV_PY%" -m pip install --upgrade pip >nul 2>nul
  "%VENV_PY%" -m pip install -r requirements.txt
  if errorlevel 1 goto :pip_failed
  echo ok 1> "%~dp0venv\.deps-ok"
) else (
  echo [2/4] Dependencies OK.
)

REM ===============================================================
REM 3/4  Sanity checks
REM ===============================================================
netstat -ano | findstr /c:"LISTENING" | findstr /c:":%PORT%" >nul
if not errorlevel 1 (
  echo [3/4] Port %PORT% is ALREADY in use.
  echo.
  echo       An instance is probably already running - just open
  echo         http://localhost:%PORT%
  echo       If you want a second one, change server.port in config.yaml.
  echo.
  goto :end
)
echo [3/4] Port %PORT% is free.

if not exist "personas" (
  echo       [hint] No personas\ folder - the character prompt is missing,
  echo              so the page will answer as a plain assistant.
)
if not exist "assets" (
  echo       [hint] No assets\ folder - avatars fall back to a built-in
  echo              flower glyph. The page still works.
)
if not exist ".env" (
  echo       [hint] No .env - cloud models stay unavailable. Copy
  echo              .env.example to .env and fill it in to enable them.
)

REM The character prompt is personas\<name>.txt - a non-ASCII filename.
REM A folder moved through a zip / USB stick can arrive with that name
REM mangled, and then it no longer matches config.yaml: the page quietly
REM degrades to a plain assistant. Catch it here, where the cause is obvious.
"%VENV_PY%" -c "import sys; from backend.persona import list_persona_names as L, describe_persona as D; sys.exit(1 if [n for n in L() if not D(n).get('file_ok')] else 0)" >nul 2>nul
if errorlevel 1 (
  echo       [hint] A character prompt file could not be read. If this
  echo              folder came from a zip / USB stick, check that personas\
  echo              still contains the .txt named in config.yaml - non-ASCII
  echo              filenames sometimes arrive mangled. The page still runs,
  echo              but the character personality will be missing.
)

if defined CHECKONLY (
  echo.
  echo [4/4] --check-only: everything is ready, not starting the server.
  echo       Run run.bat without flags to start it.
  echo.
  goto :end
)

REM ===============================================================
REM 4/4  Start the backend, wait for the port, open the browser
REM ===============================================================
echo [4/4] Starting backend in a new window...
start "Frolova backend" cmd /k ""%VENV_PY%" -m backend.main"

set /a TRIES=0
:wait_port
%PY% -c "import socket,sys; s=socket.socket(); s.settimeout(0.5); sys.exit(0 if s.connect_ex(('127.0.0.1',%PORT%))==0 else 1)" >nul 2>nul
if not errorlevel 1 goto :ready
set /a TRIES+=1
if %TRIES% GEQ 40 goto :slow_start
REM Use ping, not "timeout /t 1": timeout refuses to run when stdin is not a
REM console ("Input redirection is not supported") and would spin this loop
REM with no delay at all. A ping to localhost is a portable ~1s sleep.
ping -n 2 127.0.0.1 >nul 2>nul
goto :wait_port

:ready
echo.
echo   ============================================================
echo     Backend is up:   http://localhost:%PORT%
echo   ============================================================
echo.
echo   Optional services (the page works without them, but then it
echo   has no local model / no voice - the settings panel says so):
echo     * LM Studio    on port 1234   local model, the default
echo     * GPT-SoVITS   on port 8000   local voice, the persona voice
echo.
echo   To stop it, close the "Frolova backend" window.
echo.
if not defined NOBROWSER start "" http://localhost:%PORT%
goto :end

:slow_start
echo.
echo   Backend did not answer on port %PORT% within 40s.
echo   Look at the "Frolova backend" window - the reason is in there.
echo.
goto :end

REM ===============================================================
REM  Error paths
REM ===============================================================
:no_python
echo [ERROR] Python was not found.
echo         Install Python 3.10 or newer from https://www.python.org/downloads/
echo         and tick "Add python.exe to PATH" during setup, then run this again.
echo.
goto :end

:old_python
echo [ERROR] Your Python is too old. This project needs Python 3.10 or newer.
echo         Check with:  python --version
echo.
goto :end

:bad_python
echo [ERROR] Found something called python, but it is not a working interpreter.
echo         On Windows this is usually the Microsoft Store placeholder. Install
echo         the real one from https://www.python.org/downloads/ and tick
echo         "Add python.exe to PATH", then run this again.
echo.
goto :end

:venv_failed
echo [ERROR] Could not create the virtual environment ^(python -m venv venv^).
echo         Check that you can write to this folder and try again.
echo.
goto :end

:pip_failed
echo [ERROR] Installing dependencies failed - most likely a network problem.
echo         Run this again once you are online. If it keeps failing, try:
echo           venv\Scripts\python.exe -m pip install -r requirements.txt
echo.
goto :end

:end
pause
endlocal
