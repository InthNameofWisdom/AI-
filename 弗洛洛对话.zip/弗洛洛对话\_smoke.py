"""临时冒烟测试（验证完就删）

用 Starlette 的 TestClient 在进程内驱动真实的 WebSocket 链路，
断言原项目里 preflight.py 守着的那条不变量：

    indices == list(range(len(indices)))      # 每轮从 0 开始、连续递增

以及「TTS 挂了文字照常输出」和 /api/switch 的校验分支。

    python _smoke.py
"""

from __future__ import annotations

import sys

from fastapi.testclient import TestClient

from backend.main import app

FAILED: list[str] = []


def check(label: str, ok: bool, extra: str = "") -> None:
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}{('  -> ' + extra) if extra else ''}")
    if not ok:
        FAILED.append(label)


def one_round(client: TestClient, message: str, timeout: float = 300.0) -> dict:
    """跑一轮对话，把收到的东西按类型收好。"""
    kinds: list[str] = []
    indices: list[int] = []
    text = ""
    tools: list[tuple[str, str]] = []
    with client.websocket_connect("/ws") as ws:
        ws.send_json({"message": message, "history": []})
        while True:
            frame = ws.receive_json()
            kind = frame.get("type")
            kinds.append(kind)
            if kind == "text":
                text += frame.get("content") or ""
            elif kind == "audio":
                indices.append(frame["index"])
            elif kind == "tool":
                tools.append((frame.get("label", "?"), frame.get("status", "?")))
            elif kind == "done":
                break
    return {"kinds": kinds, "indices": indices, "text": text, "tools": tools}


def test_options(client: TestClient) -> None:
    print("\n1) /api/options")
    r = client.get("/api/options")
    check("HTTP 200", r.status_code == 200, str(r.status_code))
    j = r.json()
    check("llm 有 current 和实例列表", bool(j["llm"]["current"]) and len(j["llm"]["instances"]) > 0)
    check("tools.available 三个工具", len(j["tools"]["available"]) == 3, str(j["tools"]["available"]))
    p = j["persona"]
    check("persona 固定为 phrolova", p["current"] == "phrolova", p["current"])
    one = p["personas"][0] if p["personas"] else {}
    check("提示词文件读到了", one.get("file_ok") is True, f"chars={one.get('chars')}")
    check(
        "voice_found 三态里不是 False（没误报）",
        one.get("voice_found") is not False,
        f"voice={one.get('voice')!r} voice_found={one.get('voice_found')}",
    )


def test_switch(client: TestClient) -> None:
    print("\n2) /api/switch 校验分支")
    r = client.post("/api/switch", json={"voice": "根本不存在的音色_ZH"})
    check("坏音色名 -> 400", r.status_code == 400, str(r.status_code))
    check("报错里带了可用音色", "可用音色" in r.text, r.text[:80])

    r = client.post("/api/switch", json={"voice": None})
    check("voice=null 清掉手选覆盖 -> 200", r.status_code == 200, str(r.status_code))

    r = client.post("/api/switch", json={"tools": False})
    check("tools=false -> 200 且回 false", r.status_code == 200 and r.json().get("tools") is False)
    check("options 里也变成 false", client.get("/api/options").json()["tools"]["enabled"] is False)

    r = client.post("/api/switch", json={"tools": None})
    check("tools=null 回落到配置（true）", r.status_code == 200 and r.json().get("tools") is True)

    r = client.post("/api/switch", json={"llm": "lmstudio_local"})
    check("切 llm -> 200", r.status_code == 200, str(r.status_code))


def test_stage_direction_stripped() -> None:
    """括号里的动作描写不该被念出来（但正文里的其他内容要一字不动）。"""
    from backend.tts_client import StageDirectionStripper, clean_for_tts

    print("\n2.4) 括号动作不进语音")
    cases = [
        # (输入, 期望)
        ("（轻轻拨动琴弦）", ""),                                    # 整句都是动作 → 不合成
        ("(她停顿了一下)", ""),
        ("它不属于任何季节（轻轻拨动花瓣），只在黄昏绽放。",
         "它不属于任何季节，只在黄昏绽放。"),
        ("(she paused) 然后我继续说下去。", "然后我继续说下去。"),
        ("（他说（小声））好。", "好。"),                              # 嵌套
        ("**（动作）**这句话是正文。", "这句话是正文。"),                 # 先剥 Markdown 再剥括号
        ("你好，我是弗洛洛。", "你好，我是弗洛洛。"),                      # 正常句子不受影响
    ]
    for src, want in cases:
        got = clean_for_tts(src)
        check(f"{src!r} → {want!r}", got == want, f"实际 {got!r}")

    # ---- 流式过滤：括号跨句子时必须靠状态，单句正则救不了 ----
    # 实测踩到的：动作描写比 max_chars 长，被断句器切成好几段，
    # 中间那几段连括号字符都没有，照样会被念出来
    print("\n2.45) 括号动作跨句也不进语音（流式过滤）")
    stream = StageDirectionStripper()
    tokens = [
        "（我微微抬起眼皮，视线像被某种无形的节拍牵引着，",   # 左括号开
        "没有直勾勾地看你，而是仿佛透过你的肩膀，",            # 括号内部，没有括号字符
        "看向了某个遥远、模糊的彼方。）",                      # 右括号闭合
        "“你好吗？",
    ]
    got = "".join(stream.feed(t) for t in tokens)
    want = "“你好吗？"
    check("跨 3 个 token 的动作描写被整段吃掉，正文保留", got == want, f"实际 {got!r}")
    check("括号已闭合，深度归零", stream.depth == 0, f"depth={stream.depth}")

    plain = StageDirectionStripper()
    check("普通正文逐字不受影响", plain.feed("你好，我是弗洛洛。") == "你好，我是弗洛洛。")

    multi = StageDirectionStripper()
    out = "".join(multi.feed(t) for t in ["（动作一）", "正文A。", "(", "动作二", ")", "正文B。"])
    check("多个括号依次过滤", out == "正文A。正文B。", f"实际 {out!r}")

    lone = StageDirectionStripper()
    check("孤立的右括号照常保留", lone.feed("笑）") == "笑）", repr(lone.feed("")))

    unclosed = StageDirectionStripper()
    tail = "".join(unclosed.feed(t) for t in ["正常。", "（没闭合的动作"])
    check("左括号没闭合 → 之后的内容不出声（刻意取舍）", tail == "正常。", repr(tail))


def test_voice_found_tristate(client: TestClient) -> None:
    """切到 Edge 时，人格音色不能被误报成「音色名有误」。

    Edge 有自己的十来个音色，角色音色当然不在里面 —— 但那不是配置错误。
    这个判断是 GPT-SoVITS 对坏音色名**静默失败**时唯一能事先发现的地方，
    所以「判不了」必须返回 None，不能返回 False。
    """
    print("\n2.5) voice_found 在三态上是对的")
    on_gptsovits = client.get("/api/options").json()["persona"]["personas"][0]["voice_found"]
    check("GPT-SoVITS 上：音色存在 → True", on_gptsovits is True, str(on_gptsovits))

    r = client.post("/api/switch", json={"tts": "edge"})
    if r.status_code != 200:
        print(f"  （跳过 Edge 那段：切不过去 {r.status_code}）")
    else:
        vf = client.get("/api/options").json()["persona"]["personas"][0]["voice_found"]
        check("Edge 上：判不了 → None（不是 False，否则面板会误报）", vf is None, str(vf))
        client.post("/api/switch", json={"tts": "gptsovits"})
        back = client.get("/api/options").json()["persona"]["personas"][0]["voice_found"]
        check("切回 GPT-SoVITS 后又是 True", back is True, str(back))


def test_round(client: TestClient, label: str, message: str) -> None:
    print(f"\n3) 一轮对话（{label}）")
    got = one_round(client, message)
    kinds, indices = got["kinds"], got["indices"]
    print(f"     帧类型：{kinds}")
    print(f"     音频序号：{indices}")
    print(f"     正文 {len(got['text'])} 字符")

    check("有 first_token", "first_token" in kinds)
    check("first_token 在第一个 text 之前", kinds.index("first_token") < kinds.index("text"))
    check("最后一个是 done", kinds[-1] == "done")
    check("正文非空", len(got["text"].strip()) > 0)
    check(
        "序号连续（0..n-1）—— 这是 preflight 守的那条",
        indices == list(range(len(indices))),
        str(indices),
    )
    check("正文里没有 JSON 大括号（工具参数没串进可朗读的文本）", "{" not in got["text"])
    return got


def main() -> int:
    with TestClient(app) as client:
        test_options(client)
        test_switch(client)
        test_stage_direction_stripped()
        test_voice_found_tristate(client)
        # 跑两轮：第二轮也必须从 0 开始 —— 证明 index 是「每轮」而不是「每连接」
        test_round(client, "第一轮", "用三句话介绍一下你自己，每句短一点。")
        test_round(client, "第二轮", "再随便说两句就好。")

    print()
    if FAILED:
        print(f"==== 失败 {len(FAILED)} 项：{FAILED} ====")
        return 1
    print("==== 全部通过 ====")
    return 0


if __name__ == "__main__":
    sys.exit(main())
