/* 用 jsdom 把 index.html 真跑起来（验证完就删）
 *
 * 之前只想做语法检查，但 Edge 的 headless 在这台机器上被挡住了
 * （各种 flag 组合都返回 13）。jsdom 能在真 DOM 里执行页面，
 * 于是能覆盖真正容易静默出错的那几段：服务端帧 → 渲染 / 播放顺序 /
 * 会话落盘。这些错了页面不会报错，只会「少一句话」或者「提示一直在转」。
 *
 * 用的是原项目 node_modules 里的 jsdom（本项目不需要 npm）：
 *   NODE_PATH=..\ai-chat-demo\frontend\node_modules node _app_test.js
 */
const fs = require('fs');
const path = require('path');

/** jsdom 是可选依赖：开发机上借的是原项目 node_modules 里的那份。
    换台电脑没有它时，给一句能照着做的话，而不是 MODULE_NOT_FOUND 堆栈。 */
let JSDOM;
try {
  ({ JSDOM } = require('jsdom'));
} catch {
  console.log('这个脚本需要 jsdom，但当前环境里找不到。三种办法：');
  console.log('  1) 同级还有 ai-chat-demo 时：');
  console.log('     set NODE_PATH=..\\ai-chat-demo\\frontend\\node_modules');
  console.log('  2) 任意目录 npm i jsdom，再把 NODE_PATH 指过去');
  console.log('  3) 什么都不装：浏览器打开页面加 ?selftest=1，或跑');
  console.log('     node _selftest_node.js（零依赖，只验音频顺序和会话逻辑）');
  process.exit(2);
}

const html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');

const FAILED = [];
const ok = (label, cond, extra) => {
  console.log(`  [${cond ? 'PASS' : 'FAIL'}] ${label}${extra ? '  -> ' + extra : ''}`);
  if (!cond) FAILED.push(label);
};
const tick = (n = 1) => new Promise((res) => setTimeout(res, n));
/** 文本取值：选择器没命中时返回空串，别让断言自己抛异常 */
const textOf = (root, sel) => {
  const n = root.querySelector(sel);
  return n ? (n.textContent || '') : '';
};

/* ---------- 假 WebSocket + 假 fetch + 假 Audio ---------- */
let SOCKET = null;
const PLAYED = [];                       // 真正播出来的顺序（按解码出的段名）
const decodeSeg = (dataUrl) => {
  const b64 = String(dataUrl).split('base64,')[1] || '';
  return Buffer.from(b64, 'base64').toString('utf8');
};

class FakeWS {
  constructor(url) {
    this.url = url; this.readyState = 0; this.sent = [];
    SOCKET = this;
    setTimeout(() => { this.readyState = 1; this.onopen && this.onopen(); }, 0);
  }
  send(text) { this.sent.push(JSON.parse(text)); }
  close() { this.readyState = 3; }
  emit(obj) { this.onmessage && this.onmessage({ data: JSON.stringify(obj) }); }
}
FakeWS.OPEN = 1;

const OPTIONS = {
  llm: {
    current: 'lmstudio_local',
    instances: [
      { name: 'lmstudio_local', label: '本机 LM Studio', model: 'google/gemma-4-e4b', available: true, error: null, tools: true },
      { name: 'deepseek', label: 'DeepSeek 云端', model: 'deepseek-v4-flash', available: false, error: '缺少 DEEPSEEK_API_KEY', tools: false },
    ],
  },
  tts: {
    current: 'gptsovits', current_voice: '弗洛洛_ZH',
    voices: ['弗洛洛_ZH', '卡提希娅_ZH'], voice_error: null,
    engines: [
      { name: 'gptsovits', label: 'GPT-SoVITS 本地', format: 'wav', concurrency: 1, available: true, error: null },
      { name: 'edge', label: 'Edge-TTS 云端', format: 'mp3', concurrency: 4, available: false, error: '未安装 edge-tts' },
    ],
  },
  persona: {
    current: 'phrolova',
    personas: [{ name: 'phrolova', label: '弗洛洛', voice: '弗洛洛_ZH', voice_found: true, file_ok: true, chars: 1509, file: '弗洛洛.txt' }],
  },
  tools: { enabled: true, available: ['calculate', 'current_time', 'get_weather'], max_rounds: 4 },
  config_stale: null,
};

const dom = new JSDOM(html, {
  url: 'http://127.0.0.1:8770/',
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  beforeParse(window) {
    window.WebSocket = FakeWS;
    window.fetch = async (url) => ({ ok: true, status: 200, json: async () => (String(url).includes('/api/switch') ? { ok: true } : OPTIONS) });
    window.Audio = function (src) {
      const a = {
        src, currentTime: 0, duration: 2, onended: null, onerror: null, ontimeupdate: null,
        play() {
          PLAYED.push(decodeSeg(src));
          setTimeout(() => { a.ontimeupdate && a.ontimeupdate(); a.onended && a.onended(); }, 0);
          return Promise.resolve();
        },
        pause() {}, load() {}, removeAttribute() {},
      };
      return a;
    };
  },
});

const { window } = dom;
const doc = window.document;
const $ = (id) => doc.getElementById(id);

(async () => {
  await tick(5);

  console.log('\n1) 启动 + 设置面板数据');
  ok('WebSocket 连上了（readyState=1）', SOCKET && SOCKET.readyState === 1);
  const brandImg = doc.querySelector('#brand-avatar img');
  ok('顶栏左上角头像真的塞进图了（曾漏过：div 一直是空的）',
    !!brandImg && (brandImg.getAttribute('src') || '').endsWith('assets/frolova-icon.png'),
    brandImg ? brandImg.getAttribute('src') : '(空的 #brand-avatar)');
  ok('顶栏模型 chip 显示了实例名', $('chip-llm').textContent.includes('本机 LM Studio'), $('chip-llm').textContent);
  ok('顶栏语音 chip 显示了音色', $('chip-tts').textContent.includes('弗洛洛_ZH'), $('chip-tts').textContent);
  ok('空状态渲染出来了', !!doc.querySelector('.empty'));
  const artNode = doc.querySelector('.empty-art');
  const artSrc = artNode ? (artNode.getAttribute('src') || '') : '(没有图)';
  ok('空状态立绘用的是 assets/ 下的图', artSrc.endsWith('assets/frolova-full.png'), artSrc);
  ok('模型下拉里有 2 个实例', $('sel-llm').children.length === 2);
  ok('不可用的实例被 disabled', $('sel-llm').children[1].disabled === true);
  ok('音色下拉选中当前音色', $('sel-voice').value === '弗洛洛_ZH', $('sel-voice').value);
  ok('工具开关是打开的', $('sw-tools').checked === true);
  ok('人格提示写的是「读到了」（file_ok）', $('hint-persona').textContent.includes('1509'), $('hint-persona').textContent);

  console.log('\n2) 发一条消息');
  $('input').value = '你好呀，弗洛洛';
  $('btn-send').click();
  await tick(3);
  const sentPayload = SOCKET.sent[0];
  ok('发了 ChatRequest 且不带 type 字段', sentPayload && sentPayload.message === '你好呀，弗洛洛' && !sentPayload.type);
  ok('history 里不含当前这条', Array.isArray(sentPayload.history) && sentPayload.history.length === 0);
  ok('用户气泡出现在页面上', doc.querySelectorAll('.msg.user').length === 1);
  ok('助手气泡是 typing 状态', !!doc.querySelector('.msg.assistant .typing'));
  ok('生成中：发送键被禁用、停止键可用', $('btn-send').disabled === true && $('btn-stop').disabled === false);

  console.log('\n3) 流式文字 + 工具 chip + 乱序音频 + 单句失败');
  SOCKET.emit({ type: 'first_token' });
  SOCKET.emit({ type: 'text', content: '你来了。' });
  SOCKET.emit({ type: 'tool', name: 'calculate', label: '算数', status: 'running', detail: '(17*23)+5' });
  SOCKET.emit({ type: 'tool', name: 'calculate', label: '算数', status: 'done', detail: '396' });
  SOCKET.emit({ type: 'text', content: '先说第一句。' });
  SOCKET.emit({ type: 'text', content: '再说第二句。' });
  SOCKET.emit({ type: 'text', content: '最后一句。' });
  await tick(60);                          // 渲染是按 rAF 合并的，要等一帧以上

  const bodyText = textOf(doc, '.msg.assistant .md');
  ok('typing 指示器在首 token 后撤掉了', !doc.querySelector('.msg.assistant .typing'));
  ok('正文渲染进 DOM', bodyText.includes('你来了。') && bodyText.includes('最后一句。'), bodyText);
  ok('流式中正文末尾有光标', bodyText === '' || !!doc.querySelector('.msg.assistant .md .cursor'));
  const chip = doc.querySelector('.msg-tool-chip');
  ok('工具 chip 渲染出来了', !!chip);
  ok('chip 是 done 状态且带结果', chip && chip.className.includes('done') && chip.textContent.includes('396'), chip && chip.textContent);
  ok('工具 chip 在正文**上方**（不然正文一到就看不见了）',
    doc.querySelector('.msg.assistant .bubble').children[0].dataset.role === 'chips');

  // 乱序：先到 2、再 0、最后 1；其中 1 是失败的 → 应该播 0 和 2
  const seg = (i) => Buffer.from(`seg${i}`).toString('base64');
  SOCKET.emit({ type: 'audio', index: 2, text: '第三句', format: 'wav', data: seg(2) });
  SOCKET.emit({ type: 'audio', index: 0, text: '第一句', format: 'wav', data: seg(0) });
  SOCKET.emit({ type: 'tts_error', index: 1, text: '第二句', message: '合成失败' });
  await tick(20);
  ok('乱序到达 + 一句失败 → 播放顺序仍是 0,2（不阻塞）', JSON.stringify(PLAYED) === '["seg0","seg2"]', JSON.stringify(PLAYED));
  ok('失败那句弹了通知', [...doc.querySelectorAll('.notice-item')].some((n) => n.textContent.includes('语音没合成出来')));

  SOCKET.emit({ type: 'done' });
  await tick(5);
  ok('done 之后：生成结束、发送键恢复', $('btn-stop').disabled === true && $('btn-send').disabled === false);
  ok('会话已落盘（标题取首条消息）', JSON.parse(window.localStorage.getItem('frolova-chat:sessions')).data[0].title === '你好呀，弗洛洛');
  ok('左侧会话列表出现了一条', doc.querySelectorAll('.session-item').length === 1);

  console.log('\n4) 刷新后恢复 + 脏 localStorage 不该白屏');
  /** 带着一份既有的 localStorage 冷启动页面（要在脚本执行前塞进去，
      所以放在 beforeParse 里 —— 构造之后再塞是来不及的） */
  function bootWith(seed) {
    return new JSDOM(html, {
      url: 'http://127.0.0.1:8770/', runScripts: 'dangerously', pretendToBeVisual: true,
      beforeParse(w) {
        w.WebSocket = FakeWS;
        w.fetch = async () => ({ ok: true, status: 200, json: async () => OPTIONS });
        w.Audio = function () {
          return { play: () => Promise.resolve(), pause() {}, load() {}, removeAttribute() {},
            onended: null, onerror: null, ontimeupdate: null, currentTime: 0, duration: 1 };
        };
        for (const [k, v] of Object.entries(seed || {})) w.localStorage.setItem(k, v);
      },
    });
  }
  const goodSession = {
    v: 1,
    data: [{
      id: 'abc', title: '上次的对话', createdAt: Date.now(), updatedAt: Date.now(),
      turns: [{ role: 'user', content: '上一次我说了什么' }, { role: 'assistant', content: '你说要来听演奏。' }],
    }],
  };
  const dValid = bootWith({ 'frolova-chat:sessions': JSON.stringify(goodSession), 'frolova-chat:activeSession': JSON.stringify({ v: 1, data: 'abc' }) });
  await tick(60);
  ok('刷新后会话记录被恢复', dValid.window.document.querySelectorAll('.session-item').length === 1);
  ok('恢复的消息渲染出来了', textOf(dValid.window.document, '.msg.assistant .md').includes('要来听演奏'));

  const dDirty = bootWith({ 'frolova-chat:sessions': JSON.stringify({ v: 1, data: [{ id: 1 }, { id: 'a', title: 5 }] }) });
  await tick(60);
  ok('脏数据不白屏，页面照常渲染', !!dDirty.window.document.querySelector('.empty'));
  ok('坏会话被逐个丢掉（列表为空）', dDirty.window.document.querySelectorAll('.session-item').length === 0);

  const dOld = bootWith({ 'frolova-chat:sessions': JSON.stringify({ v: 999, data: goodSession.data }) });
  await tick(60);
  ok('schema 版本不符 → 整份丢弃，不迁移', dOld.window.document.querySelectorAll('.session-item').length === 0);

  console.log('');
  if (FAILED.length) { console.log(`==== 失败 ${FAILED.length} 项：${FAILED.join(' / ')} ====`); process.exit(1); }
  console.log('==== 全部通过 ====');
  process.exit(0);
})();
