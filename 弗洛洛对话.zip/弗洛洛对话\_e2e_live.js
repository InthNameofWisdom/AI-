/* 端到端：真页面 ←→ 真后端（验证完可以删）
 *
 * 前面两个脚本各验一半：_smoke.py 验后端帧，_app_test.js 验前端逻辑
 * （但用的是假 WS 和假音频）。这个脚本把两半接起来 —— jsdom 里跑**真页面**，
 * 用 jsdom 自带的真 WebSocket 连**真后端**，真模型、真语音。
 *
 * 这是这台机器上最接近「打开浏览器看一眼」的自动化验证（Edge 的 headless
 * 被策略挡住了，截不了图）。唯一还是假的只有 Audio：音频块本身不去解码，
 * 只按到达顺序和播放顺序记账。
 *
 *   NODE_PATH=..\ai-chat-demo\frontend\node_modules node _e2e_live.js [edge]
 *
 * 加 edge = 先切到 Edge-TTS（4 个 worker，会真并发），用来验证乱序还原。
 * 前置：后端已经在 127.0.0.1:8770 上跑着。
 *
 * ⚠ 改这个文件请用编辑器/文件工具，**别用 PowerShell 的 Set-Content**：
 * PS 5.1 的 -Encoding UTF8 会带 BOM，而 Get-Content 默认按 ANSI 读，
 * 中文会变成乱码、换行还会被压成一行。
 */
const fs = require('fs');
const path = require('path');

/** jsdom 是可选依赖（开发机上借的是原项目 node_modules 里的那份）。
    换台电脑没有它时给一句能照着做的话，而不是 MODULE_NOT_FOUND 堆栈。 */
let JSDOM;
try {
  ({ JSDOM } = require('jsdom'));
} catch {
  console.log('这个脚本需要 jsdom，但当前环境里找不到。三种办法：');
  console.log('  1) 同级还有 ai-chat-demo 时：');
  console.log('     set NODE_PATH=..\\ai-chat-demo\\frontend\\node_modules');
  console.log('  2) 任意目录 npm i jsdom，再把 NODE_PATH 指过去');
  console.log('  3) 什么都不装：浏览器打开页面加 ?selftest=1，或跑');
  console.log('     node _selftest_node.js（零依赖，只验音频顺序和会话逻辑）');
  process.exit(2);
}

const BASE = 'http://127.0.0.1:8770';
// 故意诱导模型写动作描写，好验证「括号里的内容不进语音」
const PROMPT = '跟我打个招呼吧，说说你现在在做什么，带上神态和动作的描写。';
const html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');

const FAILED = [];
const ok = (label, cond, extra) => {
  console.log(`  [${cond ? 'PASS' : 'FAIL'}] ${label}${extra ? '  -> ' + extra : ''}`);
  if (!cond) FAILED.push(label);
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const PLAYED = [];                    // 播放顺序：存整条 dataUrl
const URL_TO_INDEX = new Map();       // dataUrl → 服务端给的 index
const FRAME_ORDER = [];               // 音频帧的**到达**顺序
const FRAME_TEXTS = [];               // 每一段真正被送去合成的原句
// 之前拿「音频字节数」当指纹，结果 32 段的长度有重复、Map 后者覆盖前者，
// 报出一堆假的错位（7 号显示成 16 号）。dataUrl 是唯一的，用它当键。

const dom = new JSDOM(html, {
  url: `${BASE}/`,
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  beforeParse(window) {
    // 相对 URL 的 fetch 在 jsdom 里没有实现，转给 Node 的全局 fetch
    window.fetch = (u, o) => fetch(new URL(u, BASE).href, o);
    // 在真 WebSocket 外面套一层，记录音频帧（页面照常收消息）
    const RealWS = window.WebSocket;
    window.WebSocket = function (url, protocols) {
      const sock = new RealWS(url, protocols);
      sock.addEventListener('message', (ev) => {
        try {
          const d = JSON.parse(ev.data);
          if (d.type === 'audio') {
            FRAME_ORDER.push(d.index);
            FRAME_TEXTS.push(d.text || '');
            URL_TO_INDEX.set(`data:audio/${d.format || 'wav'};base64,${d.data}`, d.index);
          }
        } catch { /* 与本测试无关的帧 */ }
      });
      return sock;
    };
    window.WebSocket.OPEN = RealWS.OPEN;
    // 包装 Audio 以记录播放顺序，其余照常
    window.Audio = function (src) {
      const a = {
        src, currentTime: 0, duration: 2,
        onended: null, onerror: null, ontimeupdate: null,
        play() {
          PLAYED.push(src);
          setTimeout(() => { a.ontimeupdate && a.ontimeupdate(); a.onended && a.onended(); }, 0);
          return Promise.resolve();
        },
        pause() {}, load() {}, removeAttribute() {},
      };
      return a;
    };
    window.onerror = (msg) => { console.log(`  [页面抛异常] ${msg}`); FAILED.push('页面抛异常'); };
  },
});

const { window } = dom;
const doc = window.document;
const $ = (id) => doc.getElementById(id);

(async () => {
  console.log(`端到端：${BASE}  ←→  真模型 + 真语音`);

  // 想验证「乱序到达也能按序播放」，必须让后端真的并发合成：
  // GPT-SoVITS 是 concurrency 1（不并发就不会乱），Edge 是 4。
  if (process.argv.includes('edge')) {
    const r = await fetch(`${BASE}/api/switch`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tts: 'edge' }),
    });
    console.log(`  切到 Edge-TTS（4 个 worker，会真并发）：HTTP ${r.status}`);
    if (!r.ok) console.log('  切不过去，本轮只能验 GPT-SoVITS');
  }
  await sleep(1200);

  ok('页面连上了后端（WS open）', $('pulse').className.includes('on'), $('pulse').className);
  ok('顶栏显示了当前模型', $('chip-llm').textContent.trim().length > 2, $('chip-llm').textContent);
  ok('设置面板拿到了 options', $('sel-llm').children.length > 0, `${$('sel-llm').children.length} 个实例`);

  console.log(`\n发一句：${PROMPT}`);
  $('input').value = PROMPT;
  $('btn-send').click();

  let waited = 0;
  while (waited < 240000) {
    if ($('btn-stop').disabled === true && doc.querySelectorAll('.msg.assistant').length > 0) {
      const body = doc.querySelector('.msg.assistant .md');
      if (body && body.textContent && body.textContent !== '（没有内容）') break;
    }
    await sleep(500); waited += 500;
  }
  await sleep(1500);                  // 让音频队列跑完

  const reply = (doc.querySelector('.msg.assistant .md') || {}).textContent || '';
  console.log(`\n弗洛洛的回复（${reply.length} 字）：\n${reply}\n`);
  console.log(`实际送去合成的 ${FRAME_TEXTS.length} 段：`);
  FRAME_TEXTS.forEach((t, i) => console.log(`  ${i}. ${t}`));
  console.log('');

  const withParen = FRAME_TEXTS.filter((t) => /[（(]/.test(t));
  const replyHasParen = /[（(]/.test(reply);

  ok('拿到了非空回复', reply.trim().length > 5, `${reply.length} 字`);
  ok('回复里没有人设崩塌的痕迹（不是「我是 AI 助手」）', !/作为一个?AI|语言模型/.test(reply));
  ok('收到的语音段数 == 播出的段数', PLAYED.length === FRAME_ORDER.length,
    `合成 ${FRAME_ORDER.length}，播放 ${PLAYED.length}`);
  ok('服务端编号是 0..n-1 连续的（到达次序可能乱）',
    JSON.stringify([...FRAME_ORDER].sort((a, b) => a - b)) === JSON.stringify(FRAME_ORDER.map((_, i) => i)),
    JSON.stringify(FRAME_ORDER));

  const playIdx = PLAYED.map((url) => URL_TO_INDEX.get(url));
  ok('**播放顺序严格是 0,1,2,…**（这才是顺序还原的意义）',
    playIdx.length > 0 && JSON.stringify(playIdx) === JSON.stringify(playIdx.map((_, i) => i)),
    `播放=${JSON.stringify(playIdx)}`);

  if (FRAME_ORDER.length > 1) {
    const shuffled = JSON.stringify(FRAME_ORDER) !== JSON.stringify([...FRAME_ORDER].sort((a, b) => a - b));
    console.log(shuffled
      ? `  [信息] 到达顺序确实是乱的（${JSON.stringify(FRAME_ORDER)}）—— 本轮用真并发验证到了顺序还原 ★`
      : `  [信息] 本轮到达恰好也是顺序的（${JSON.stringify(FRAME_ORDER)}）；乱序场景由 _app_test.js 注入覆盖`);
  }

  console.log('');
  console.log(`  [信息] 回复正文里${replyHasParen ? '**有**' : '没有'}括号动作描写 —— `
    + (replyHasParen ? '它仍然显示在页面上，但下面这条断言检查的是它没被念出来' : '本轮模型没写，这条断言的说服力有限'));
  ok('被送去朗读的句子里没有括号动作描写', withParen.length === 0,
    withParen.length ? JSON.stringify(withParen) : '（已过滤）');

  ok('会话落盘了', !!window.localStorage.getItem('frolova-chat:sessions'));
  ok('没有页面级异常', !FAILED.includes('页面抛异常'));

  console.log('');
  if (FAILED.length) { console.log(`==== 失败 ${FAILED.length} 项：${FAILED.join(' / ')} ====`); process.exit(1); }
  console.log('==== 端到端通过 ====');
  process.exit(0);
})().catch((exc) => { console.error('脚本自身出错：', exc); process.exit(1); });
