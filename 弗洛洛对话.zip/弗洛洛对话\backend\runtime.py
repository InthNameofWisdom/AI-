# -*- coding: utf-8 -*-
"""运行时切换层：让前端能在**不重启后端**的情况下换
LLM provider / TTS 引擎 / TTS 音色 / 工具调用开关 / 人格（角色）。
=====================================================================

为什么要有这一层
----------------
配置的读取链路是：``config.yaml`` + ``.env`` → ``config.load_config()``
（带 ``@lru_cache(maxsize=1)``）。缓存意味着「改了配置要重启才生效」，
这正是原来演示里「改 config.yaml → 重启后端」那一步的由来。

要做热切换，有两条路：

  A. 真的去改写 config.yaml，再 ``load_config.cache_clear()``
  B. 只在内存里记一个「覆盖值」，优先级高于配置文件

选了 B，原因有三：

  * ``.env`` 里放着 API Key，程序去改写磁盘配置既没必要也危险；
  * 写文件失败（只读挂载、被编辑器占用）会在演示现场变成硬故障；
  * 「当前用哪个」本质是**会话状态**，不是**配置**，放在内存里语义更对。

优先级：``运行时覆盖`` > ``config.yaml`` > ``内置默认``
传 ``None`` 给 ``set_xxx()`` 即清除覆盖、回到配置文件的值。

这一层刻意做得很薄 —— 它不解析、不校验，只记名字。
真正的构造与校验仍然由 ``llm_provider.create_provider()`` /
``tts_client.create_tts_engine()`` 负责（它们本来就带完整报错）。
"""
from __future__ import annotations

from typing import Any

from .config import load_config

__all__ = [
    "resolve_llm_name",
    "resolve_tts_name",
    "resolve_tts_voice",
    "resolve_persona_name",
    "resolve_persona_voice",
    "resolve_tools_enabled",
    "set_llm",
    "set_tts",
    "set_tts_voice",
    "set_persona",
    "set_persona_voice",
    "set_tools",
    "clear",
    "snapshot",
]

_llm_override: str | None = None
_tts_override: str | None = None
_persona_override: str | None = None

# 工具调用的总开关。⚠ 这是这里**唯一**的布尔覆盖值，取值必须用 `is not None`
# 判断，不能沿用下面 _clean() 那套真值判断 —— 见 resolve_tools_enabled() 的注释。
_tools_override: bool | None = None

# 引擎名 → 音色。**按引擎分别记**：
# 从 GPT-SoVITS 切到 Edge 再切回来时，各自选过的音色应该还在 ——
# 用一个全局变量的话，切引擎会把另一边的选择冲掉，切回去就变回默认了。
#
# ⚠ 这一层是**用户手选的**，不包含人格绑定的音色 —— 那个在下面的
# _persona_voices。两者分开的理由见 resolve_persona_voice() 的注释。
_voice_overrides: dict[str, str] = {}

# 引擎名 → 音色，由**当前人格**推导（不是累加状态）。
#
# 为什么要和 _voice_overrides 分成两层：人格音色如果也写进上面那本字典，
# 会有三条路径留下**永久错配**（人格是弗洛洛、声音还是纳西妲，且回不去）：
#
#   1. 人格绑的音色**没命中**（比如服务器上拼写不一致）→ 若选择「不设值」，
#      上一个人格的音色就被留着了；
#   2. 人格**没绑音色**（比如回「默认助手」）→ 同上，却还在用上一个人的声音；
#   3. 用户在设置面板点「回到默认音色」→ set_tts_voice(engine, None)
#      会把人格写进去的那份**一起清掉**，人格层不会重新套上。
#
# 分成两层之后，「人格 ↔ 音色」这个对应关系在下面这些路径下都成立：
# 切引擎来回、切人格来回、点默认音色、拉不到音色列表。
_persona_voices: dict[str, str] = {}


def _clean(name: str | None) -> str | None:
    """空串 / 纯空白一律当成「没设置」，避免前端传 "" 时把默认值顶掉。"""
    if name is None:
        return None
    stripped = str(name).strip()
    return stripped or None


def _engine_key(name: str | None) -> str | None:
    """引擎名的**归一化**键。

    `tts_client.create_tts_engine()` 在 :779 把段名 `.strip().lower()` 之后才用，
    而这里如果照原样存，配置里段名带大写时就会「存进 A、查的是 a」——
    音色覆盖**静默失效**（页面上选了音色，合成时却用回默认值）。
    所以音色这两层统一用归一化后的键。
    """
    cleaned = _clean(name)
    return cleaned.lower() if cleaned else None


def resolve_llm_name() -> str:
    """当前生效的 LLM 实例名。"""
    if _llm_override:
        return _llm_override
    cfg = load_config()
    return str((cfg.get("llm") or {}).get("provider") or "").strip()


def resolve_tts_name() -> str:
    """当前生效的 TTS 引擎名（config.yaml 里的段名）。"""
    if _tts_override:
        return _tts_override
    cfg = load_config()
    return str((cfg.get("tts") or {}).get("engine") or "gptsovits").strip()


def resolve_tts_voice(engine_name: str) -> str | None:
    """某个引擎当前被**用户手选**的音色。没指定过就返回 None。

    ⚠ 这里**只**看用户手选那一层。人格绑定的音色在 resolve_persona_voice()，
    真正生效的优先级由 tts_client.create_tts_engine() 决定
    （用户手选 > 人格音色 > config.yaml）。
    """
    key = _engine_key(engine_name)
    return _voice_overrides.get(key) if key else None


def resolve_persona_name() -> str:
    """当前生效的人格名。空串 = 默认助手（不套角色，只用通用规则）。"""
    if _persona_override:
        return _persona_override
    cfg = load_config()
    return str((cfg.get("persona") or {}).get("current") or "").strip()


def resolve_persona_voice(engine_name: str) -> str | None:
    """**当前人格**给某个引擎绑定的音色；没绑就 None。

    只有「这个引擎声明过人格音色」时才有值 —— 切到 Edge-TTS 时那边
    没有这些音色，返回 None，于是它用自己配置里的音色。这是**预期行为**，
    不是坏了（页面上会说明）。
    """
    key = _engine_key(engine_name)
    return _persona_voices.get(key) if key else None


def set_llm(name: str | None) -> None:
    """切换 LLM 实例；传 None 表示回到 config.yaml 的 llm.provider。"""
    global _llm_override
    _llm_override = _clean(name)


def set_tts(name: str | None) -> None:
    """切换 TTS 引擎；传 None 表示回到 config.yaml 的 tts.engine。"""
    global _tts_override
    _tts_override = _clean(name)


def resolve_tools_enabled() -> bool:
    """工具调用的**总**开关。运行时覆盖优先，其次 config.yaml 的 tools.enabled。

    ⚠ 这里**必须**用 `is not None` 判断，不能照抄上面两个 resolve_* 的写法。
    它们的覆盖值是字符串，靠 `if _llm_override:` 的真值就能区分「设过」和「没设」；
    但布尔值不行：`False` 是 falsy，写成 `if _tools_override:` 的话，
    「显式关掉工具」会被当成「没有覆盖」，于是回落到配置里的 `enabled: true` ——
    表现是**点了关闭但工具照常被调用**，而且完全不报错。
    这是本模块里唯一一个布尔覆盖值，所以特意留这段注释。
    """
    if _tools_override is not None:
        return _tools_override
    section = load_config().get("tools") or {}
    if isinstance(section, dict) and "enabled" in section:
        return bool(section.get("enabled"))
    return True


def set_tools(enabled: bool | None) -> None:
    """切换工具调用总开关；传 None 表示回到 config.yaml 的 tools.enabled。"""
    global _tools_override
    _tools_override = None if enabled is None else bool(enabled)


def set_persona(name: str | None) -> None:
    """切换人格；传 None 表示回到 config.yaml 的 persona.current。

    ⚠ 本函数**不碰音色**。人格音色的联动由 main.switch() 编排，因为那一步
    需要校验（音色在不在服务器列表里），而这一层刻意「不解析、不校验，
    只记名字」。
    """
    global _persona_override
    _persona_override = _clean(name)


def set_persona_voice(engine_name: str, voice: str | None) -> None:
    """给某个引擎设置**人格推导出来的**音色；传 None 表示这个人格不给它绑音色。"""
    key = _engine_key(engine_name)
    if not key:
        return
    value = _clean(voice)
    if value is None:
        _persona_voices.pop(key, None)
    else:
        _persona_voices[key] = value


def set_tts_voice(engine_name: str, voice: str | None) -> None:
    """给某个引擎设置**用户手选的**音色；传 None 表示回到该引擎配置里的值。

    ⚠ 「回到默认值」只清这一层，**不影响**人格绑定的音色
    （那个由 set_persona_voice 管）—— 见 _persona_voices 的注释。
    """
    key = _engine_key(engine_name)
    if not key:
        return
    value = _clean(voice)
    if value is None:
        _voice_overrides.pop(key, None)
    else:
        _voice_overrides[key] = value


def clear() -> None:
    """清除全部覆盖，回到配置文件。"""
    global _llm_override, _tts_override, _persona_override, _tools_override
    _llm_override = None
    _tts_override = None
    _persona_override = None
    _tools_override = None
    _voice_overrides.clear()
    _persona_voices.clear()


def snapshot() -> dict[str, Any]:
    """当前的覆盖值（None = 未覆盖），供 /api/options 区分
    「是配置文件里选的」还是「运行时切过来的」。"""
    return {
        "llm": _llm_override,
        "tts": _tts_override,
        "tts_voice": dict(_voice_overrides),
        "persona": _persona_override,
        "persona_voice": dict(_persona_voices),
        "tools": _tools_override,
    }
