# -*- coding: utf-8 -*-
"""
TTS 客户端：可插拔引擎 + 分句逻辑
=================================
结构分四层：

  ① 抽象层  TTSEngine           —— 只要实现 synthesize() 就能接入新引擎
  ② 注册层  register_tts_type() —— 把实现类登记进注册表，工厂按配置的 type 查找
  ③ 实现层  GPTSoVITSEngine / EdgeTTSEngine
  ④ 工具层  split_sentences() / clean_for_tts() —— 分句与文本清洗

接入一个新引擎的完整步骤：

    1. 继承 TTSEngine，实现 synthesize()
    2. 打上 @register_tts_type("你的类型名")
    3. 在 config.yaml 的 tts 段加一个小节（段名随意，type 填注册名）

工厂不需要改 —— 它按 type 查注册表。这和 llm_provider.py 的
register_provider_type 是同一套模式，刻意保持一致。

关于「流式语音」的重要事实
--------------------------
GPT-SoVITS 是**整句进、整段出**的服务，没有逐字流式接口，
官方文档标注单次推理耗时「秒级到分钟级」。

所以本项目实现的不是「逐字流式语音」，而是：
    文字流式显示  +  语音逐句并行合成、排队播放
靠 backend/main.py 里的并发预取队列把句与句之间的空档压到最小。
演示时要如实说明这一点，别说成「音频也是流式的」。
"""
from __future__ import annotations

import inspect
import json
import logging
import re
from abc import ABC, abstractmethod
from typing import Any, Sequence

import httpx

from .config import load_config, missing_env_hint
from .runtime import resolve_persona_voice, resolve_tts_name, resolve_tts_voice

# Edge-TTS 是**可选**依赖：没装它，用 GPT-SoVITS 照样能跑。
# 所以顶层不断言、不抛异常，只记成 None，等真正要用 Edge 引擎时
# 再给出「去 pip install edge-tts」的提示。
# 反过来做（顶层直接 import）会让没装这个包的机器整个后端起不来，
# 为了一个可选引擎付这个代价不值得。
try:  # pragma: no cover - 取决于运行环境
    import edge_tts
except ImportError:  # pragma: no cover
    edge_tts = None

logger = logging.getLogger(__name__)

DEFAULT_DELIMITERS: tuple[str, ...] = ("。", "！", "？", ".", "!", "?", "\n", "；", ";")
DEFAULT_MAX_CHARS = 30

# 「软停顿」：只在**被迫按长度切句**时用来找更自然的切口。
# 不参与正常断句 —— 否则每个逗号都会切一刀，语音会变得很碎。
DEFAULT_SOFT_BREAKS: tuple[str, ...] = ("，", ",", "、", "：", ":")

_CODE_FENCE = "```"

# tts 段里这些键是**所有引擎共用**的，不属于任何一个引擎的小节。
# 用来把「公共参数」和「某个引擎的参数」区分开 —— 见 _engine_section()。
SHARED_TTS_KEYS: frozenset[str] = frozenset(
    {"engine", "max_chars", "delimiters", "queue_maxsize"}
)

#: Edge-TTS 的默认音色（中文女声）
DEFAULT_EDGE_VOICE = "zh-CN-XiaoxiaoNeural"


class TTSError(RuntimeError):
    """TTS 合成失败。"""


# ======================================================================
# ③ 工具层：文本清洗
# ======================================================================

# Markdown 符号如果不剥掉，TTS 会把「星号」「井号」念出来，非常影响观感。
# 顺序有讲究：先处理结构（代码块/链接），再处理行内的强调符号。
_MD_RULES: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"```[\s\S]*?```"), " "),              # 围栏代码块整体丢弃
    (re.compile(r"~~~[\s\S]*?~~~"), " "),
    (re.compile(r"!\[[^\]]*\]\([^)]*\)"), " "),        # 图片整体丢弃
    (re.compile(r"\[([^\]]*)\]\([^)]*\)"), r"\1"),     # 链接只保留文字
    (re.compile(r"^\s{0,3}#{1,6}\s*", re.MULTILINE), ""),   # 标题井号
    (re.compile(r"^\s{0,3}>\s?", re.MULTILINE), ""),        # 引用
    (re.compile(r"^\s*[-*+]\s+", re.MULTILINE), ""),        # 无序列表
    (re.compile(r"^\s*\d+[.、)]\s+", re.MULTILINE), ""),    # 有序列表
    (re.compile(r"^\s*[-*_]{3,}\s*$", re.MULTILINE), ""),   # 分隔线
    (re.compile(r"[*_~`]{1,3}"), ""),                  # 强调 / 行内代码符号
    (re.compile(r"\|"), " "),                          # 表格竖线
    (re.compile(r"\\"), ""),                           # 转义反斜杠
)

# 括号里的动作描写 / 舞台提示，例如「（轻轻拨动琴弦）」「(她停顿了一下)」。
# 这类文字是**给眼睛看的**，念出来会打断语气 —— 角色正说着话，突然平铺直叙地
# 念一句「她停顿了一下」，听起来像旁白。所以合成前整段去掉。
# 只去掉最内层、循环几次是为了处理「（他说（小声））」这种嵌套。
_STAGE_DIRECTION = re.compile(r"[（(][^（）()]*[）)]")


class StageDirectionStripper:
    """跨 token 过滤括号动作描写（流式安全）。

    为什么不能只在单句里用正则替换掉：
    动作描写经常**比 max_chars 还长**，断句器会把它切成好几段 ——

        原文：（我微微抬起眼皮，视线像被某种无形的节拍牵引着，
              没有直勾勾地看你，而是看向了某个遥远的彼方。）“你好吗？”

    max_chars=30 时会被切成 3~4 段。第一段只有左括号（正则要求配对，匹配不上），
    中间几段**连括号字符都没有**，于是整段描写照样被念出来 —— 实测就是这样
    （32 段里混着 5 段动作描写）。所以括号深度必须跨 token、跨句子保留。

    用法：每轮对话建一个实例，token 依次喂 `feed()`，只用它的返回值拼 buffer。
    显示用的原文不走这里 —— 动作描写仍然显示在页面上，只是不朗读。

    ⚠ 左括号一直没闭合时，后面的内容会被一直吞掉（直到本轮结束）。
    这是刻意的取舍：正常输出里括号总是配对的；真出现截断，宁可少念也不要
    把动作描写当正文念出来。
    """

    def __init__(self) -> None:
        self.depth = 0

    def feed(self, text: str) -> str:
        out: list[str] = []
        for ch in text:
            if ch in "（(":
                self.depth += 1
            elif ch in "）)":
                if self.depth > 0:
                    self.depth -= 1
                else:
                    out.append(ch)          # 多出来的右括号照常保留
            elif self.depth == 0:
                out.append(ch)
        return "".join(out)


def clean_for_tts(text: str) -> str:
    """把一句文本清洗成适合朗读的纯文本。

    代码块会被整段丢弃 —— 朗读 `for i in range(10)` 这种内容
    对演示没有任何帮助，只会让人听不清。括号里的动作描写同样不念（见上）。
    """
    out = text
    for pattern, repl in _MD_RULES:
        out = pattern.sub(repl, out)
    # 放在 Markdown 之后：**（动作）** 先被剥成 （动作），这里再去掉
    for _ in range(3):
        stripped = _STAGE_DIRECTION.sub("", out)
        if stripped == out:
            break
        out = stripped
    # 折叠空白（含换行），避免 TTS 在不该停顿的地方停顿
    out = re.sub(r"\s+", " ", out)
    # 只剩标点/符号、没有一个文字字符的片段不送 TTS
    if not re.search(r"[0-9A-Za-z一-鿿]", out):
        return ""
    return out.strip()


def in_code_fence(text: str) -> bool:
    """判断文本是否停在未闭合的 ``` 代码块内部。"""
    return text.count(_CODE_FENCE) % 2 == 1


def split_sentences(
    buffer: str,
    delimiters: Sequence[str] = DEFAULT_DELIMITERS,
    max_chars: int = DEFAULT_MAX_CHARS,
    soft_breaks: Sequence[str] = DEFAULT_SOFT_BREAKS,
) -> tuple[list[str], str]:
    """从缓冲区切出所有已经完整的句子。

    返回 ``(句子列表, 剩余未完成部分)``。

    断句规则（PROJECT_MEMORY §9.3）：
      * 遇到分隔符即断句，分隔符归入前一句
      * 没有分隔符但长度达到 max_chars 时强制断句，防止长句一直等不到标点
      * **代码块内部不断句** —— 否则会切在 ``` 中间，把代码碎片送去朗读
      * 强制断句时**回退到最近的软停顿（逗号/顿号等）**，避免把词切成两半

    最后一条很重要。举例，max_chars=30 时对一个 33 字的句子：
        硬切   -> "...生活节奏舒适的好去" + "处。"     后一段是 2 字碎片，听着很怪
        回退后 -> "...生活节奏舒适的好去处。"          一个完整的句子
    """
    delim_set = set(delimiters)
    soft_set = set(soft_breaks) - delim_set
    # 最多往回找这么远；再远就宁可硬切，不然切出来的句子太短
    lookback = max(4, max_chars // 2)

    sentences: list[str] = []

    start = 0
    i = 0
    fence_open = False

    while i < len(buffer):
        if buffer.startswith(_CODE_FENCE, i):
            fence_open = not fence_open
            i += 3
            continue

        char = buffer[i]
        if fence_open:
            i += 1
            continue

        if char in delim_set:
            cut = i
        elif (i - start + 1) >= max_chars:
            # 到长度上限了：优先回退到最近的软停顿
            cut = i
            for j in range(i - 1, max(start, i - lookback) - 1, -1):
                if buffer[j] in soft_set and buffer[start : j + 1].count(_CODE_FENCE) % 2 == 0:
                    cut = j
                    break
        else:
            i += 1
            continue

        piece = buffer[start : cut + 1].strip()
        if piece:
            sentences.append(piece)
        start = cut + 1
        i = cut + 1

    return sentences, buffer[start:]


# ======================================================================
# ① 抽象层
# ======================================================================

class TTSEngine(ABC):
    """语音合成引擎抽象基类。

    为什么这些属性在基类上而不是各实现里各自为政：
    ``/api/health`` 早就在读 ``engine.version()`` / ``list_models()`` /
    ``model_name`` / ``base_url``，但它们**从来没在基类上出现过** ——
    也就是说自检代码一直默默依赖着 GPT-SoVITS 专属的实现细节。
    接入第二个引擎时，health 会直接 AttributeError，整个页面显示「语音异常」。
    所以这里把「自检需要什么」正式写进契约，允许实现用空值表示「我没有这项能力」。
    """

    #: 引擎类型名，和 @register_tts_type() 注册的一致
    name: str = "unknown"
    #: 给人看的名字，前端下拉框直接显示
    label: str = ""
    #: 服务地址（本地引擎是自己的地址，云端引擎是服务端点）
    base_url: str = ""
    #: 音色 / 模型标识。没有「模型」概念的引擎（如 Edge-TTS）可以放音色名
    model_name: str = ""
    #: 音频容器格式。前端拿它拼 ``data:audio/<format>;base64,``
    audio_format: str = "wav"
    #: 该引擎建议的并发预取 worker 数。本地抢显存的引擎要设 1，云端可以放开
    concurrency: int = 1
    #: 自检失败时给用户看的排查提示（按引擎不同而不同）
    hint: str = ""

    #: 这个引擎能不能承载 persona.<名字>.voice 里那套角色音色。
    #:
    #: 默认 False：别的引擎（比如 Edge-TTS）有自己的音色体系，拿它的列表去比对
    #: 角色音色只会得出「音色名有误」这种**误导**结论 —— 而那个判断是「服务器
    #: 对坏音色名静默失败」唯一能事先发现的地方，不能用错。判不了就该返回 None。
    hosts_persona_voices: bool = False

    @abstractmethod
    async def synthesize(self, text: str) -> bytes:
        """把一句话合成为音频字节。

        返回的是**容器格式由 audio_format 决定**的完整音频，
        调用方不关心是 wav 还是 mp3。
        """
        raise NotImplementedError

    async def probe(self) -> dict[str, Any]:
        """自检探测（可选能力）。

        返回会被合并进 ``/api/health`` 的 ``tts`` 段。约定能提供就提供：

            {"version": ..., "models": ..., "model_found": bool, "warning": str}

        默认返回空字典 = 「本引擎不支持探测」。health 会如实显示成
        「未探测」，而不是误报成失败 —— 这是刻意区分开的：
        「没这个能力」和「有能力但挂了」是两回事。
        """
        return {}

    async def list_voices(self) -> list[str]:
        """这个引擎可用哪些音色。

        返回空列表 = 「本引擎不支持 / 未提供音色列表」，
        前端会把音色下拉框禁掉并说明原因。

        ⚠ 实现时注意：**别把服务器给的原始列表直接暴露出去** ——
        GPT-SoVITS 的列表里混着不能用的条目（见那边 list_voices 的注释）。
        """
        return []

    def set_voice(self, voice: str) -> None:
        """切换音色。

        默认实现改 ``model_name`` —— 现有两个引擎的「当前音色」都落在它上面，
        所以默认实现就够用。需要同步别的字段的引擎才覆写它。

        ⚠ 本方法**不做校验**：名字合不合法由调用方负责
        （先用 list_voices() 比对一次）。
        """
        if voice:
            self.model_name = voice

    @classmethod
    def from_config(cls, section: dict[str, Any]) -> "TTSEngine":
        """按配置小节构造实例。

        默认实现足够通用：用反射挑出构造器认识的键透传进去，
        剩下的键打一条 warning（免得配置里 `voece` 这种拼写错误
        被静默吞掉，表现成「改了配置没反应」）。

        只有需要把配置**重新组合**的引擎才需要覆写它
        （比如必填项要给出比 TypeError 更友好的报错）。
        """
        accepted = {
            name
            for name, param in inspect.signature(cls.__init__).parameters.items()
            if name != "self"
            and param.kind
            in (param.POSITIONAL_OR_KEYWORD, param.KEYWORD_ONLY)
        }
        kwargs: dict[str, Any] = {}
        for key, value in section.items():
            if key in _RESERVED_SECTION_KEYS:
                continue
            if key in accepted:
                kwargs[key] = value
            else:
                logger.warning(
                    "TTS 引擎 %s 不认识配置项 %r，已忽略（拼写错了？）",
                    cls.__name__,
                    key,
                )
        return cls(**kwargs)

    async def aclose(self) -> None:
        """释放底层连接。"""
        return None


#: 配置小节里这些键不参与构造（type 用于查注册表，其余是给工厂/前端的元信息）
_RESERVED_SECTION_KEYS = {"type"}


# ======================================================================
# ② 注册层（与 llm_provider.register_provider_type 同一套模式）
# ======================================================================

_TTS_TYPES: dict[str, type[TTSEngine]] = {}


def register_tts_type(type_name: str):
    """把一个 TTSEngine 子类注册到工厂里，供 config.yaml 的 type 字段引用。"""

    def decorator(cls: type[TTSEngine]) -> type[TTSEngine]:
        key = type_name.strip().lower()
        if key in _TTS_TYPES:
            raise ValueError(f"TTS 引擎类型 {key!r} 已经注册过了")
        _TTS_TYPES[key] = cls
        return cls

    return decorator


def available_tts_types() -> list[str]:
    """已注册的引擎类型名，供报错信息和 /api/options 使用。"""
    return sorted(_TTS_TYPES)


# ======================================================================
# ② 实现层：GPT-SoVITS
# ======================================================================

@register_tts_type("gptsovits")
class GPTSoVITSEngine(TTSEngine):
    """对接 GPT-SoVITS 风格的 AI 配音服务器。

    调用链是**两步**（这一点和 OpenAI 兼容接口不同，容易搞混）：

        POST {base_url}/infer_single
             -> {"audio_url": "http://0.0.0.0:8000/outputs/<hash>.wav"}
        GET  {base_url}/outputs/<hash>.wav
             -> wav 二进制

    即 infer_single 返回的是一张「取货单」，还要再下载一次。
    """

    name = "gptsovits"
    label = "GPT-SoVITS 本地"
    audio_format = "wav"
    hint = "确认 GPT-SoVITS 服务已启动、端口正确（默认 127.0.0.1:8000）"
    # 角色音色（弗洛洛_ZH 之类）就是这台服务器上的音色，所以它能承载
    hosts_persona_voices = True

    def __init__(
        self,
        base_url: str,
        model_name: str,
        text_lang: str = "中英混合",
        prompt_text_lang: str = "中文",
        emotion: str = "默认",
        media_type: str = "wav",
        timeout: float = 600.0,
        concurrency: int = 1,
        label: str = "",
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model_name = model_name
        self.media_type = media_type
        self.timeout = timeout
        # 实测：同一块 GPU 上并发跑 2 条推理会互相抢显存，句子一长就慢一个数量级
        # （首段音频 57.8s vs 17.3s，见 README「性能实测」）。所以默认 1。
        self.concurrency = max(1, int(concurrency))
        if label:
            self.label = label

        # ------------------------------------------------------------------
        # 坑：text_lang / prompt_text_lang / emotion 三个字段必须同时非空。
        # 缺任意一个，服务器**不会报错**，只会静默返回一个没有 audio_url
        # 的结果，看起来像是「模型名写错了」，极难排查。
        # 这里给死兜底值，宁可朗读效果差一点，也不能整条链路哑掉。
        # ------------------------------------------------------------------
        self.text_lang = text_lang or "中英混合"
        self.prompt_text_lang = prompt_text_lang or "中文"
        self.emotion = emotion or "默认"

        self._client: httpx.AsyncClient | None = None

    @classmethod
    def from_config(cls, section: dict[str, Any]) -> "GPTSoVITSEngine":
        """覆写默认实现：model_name 是必填的，缺了就报一句有用的话。

        走默认实现的话，这里会抛一个 `__init__() missing 1 required
        positional argument: 'model_name'` —— 对着演示现场的人毫无帮助。
        """
        if not str(section.get("model_name") or "").strip():
            raise TTSError(
                "config.yaml 的 tts 段里，这个 GPT-SoVITS 小节没有填 model_name。\n"
                "  -> 服务器 /models/v4 返回的模型名要一字不差地填进来，"
                "可以先访问 base_url/models/v4 看一眼实际值。"
            )
        return super().from_config(section)

    async def _get_client(self) -> httpx.AsyncClient:
        """惰性创建并复用 AsyncClient。

        复用连接池很重要：句子是并发合成的，每句都新建一次 TCP 连接
        会显著抬高首字节延迟，把「并发预取」的收益吃掉。
        """
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=self.timeout, follow_redirects=True
            )
        return self._client

    async def synthesize(self, text: str) -> bytes:
        client = await self._get_client()

        payload = {
            "model_name": self.model_name,
            "text": text,
            "text_lang": self.text_lang,
            "prompt_text_lang": self.prompt_text_lang,
            "emotion": self.emotion,
            "media_type": self.media_type,
        }

        try:
            resp = await client.post(f"{self.base_url}/infer_single", json=payload)
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            raise TTSError(
                f"调用 TTS 服务器失败（{self.base_url}/infer_single）：{exc}"
            ) from exc

        result = resp.json()
        if not isinstance(result, dict):
            raise TTSError(f"TTS 返回了非预期结构：{result!r}")

        # 不同版本可能叫 audio_url 或 result_path，两个都兜一下
        audio_ref = result.get("audio_url") or result.get("result_path")
        if not audio_ref:
            raise TTSError(
                "TTS 没有返回音频地址（audio_url 为空）。\n"
                "  最常见原因：text_lang / prompt_text_lang / emotion "
                "三个字段没有同时传值，或 model_name 与实际安装的模型不符。\n"
                f"  当前请求：model={self.model_name!r}, "
                f"text_lang={self.text_lang!r}, "
                f"prompt_text_lang={self.prompt_text_lang!r}, "
                f"emotion={self.emotion!r}\n"
                f"  服务器返回：{result!r}"
            )

        # ------------------------------------------------------------------
        # 坑：audio_url 里的 host 通常是服务器自己的视角（0.0.0.0），
        # 从别的机器 / 浏览器角度看是访问不到的。
        # 所以【只取最后一段文件名】，再用配置里的 base_url 重新拼一次。
        # ------------------------------------------------------------------
        filename = str(audio_ref).rstrip("/").split("/")[-1]

        try:
            audio_resp = await client.get(f"{self.base_url}/outputs/{filename}")
            audio_resp.raise_for_status()
        except httpx.HTTPError as exc:
            raise TTSError(f"下载音频失败（{self.base_url}/outputs/{filename}）：{exc}") from exc

        return audio_resp.content

    async def aclose(self) -> None:
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    # ---------- 供 /api/health 自检使用 ----------

    async def list_voices(self) -> list[str]:
        """GET /models/v4 —— 服务器上装了哪些音色。

        ⚠ 服务器返回的列表里**混着不能用的条目**，必须清洗：

            卡提希娅_ZH.zip       <- 压缩包
            原神-中文-纳西妲_ZH    <- 解压后的目录（能用）
            弗洛洛_ZH             <- 能用
            弗洛洛_ZH.zip         <- 压缩包

        实测：**带 .zip 的名字一律不能用**，服务器不报错、只静默返回空
        audio_url（就是那个本项目已经被坑过一次的静默失败）。
        而「列表里只有 .zip 版本」的那些（比如 卡提希娅_ZH），
        去掉后缀反而能用 —— 所以统一剥掉 .zip 再按原名去重是安全的。

        ⚠ 另一个坑：`models` 字段是 **dict 不是 list**，长这样 ——

            {"models": {
                "卡提希娅_ZH":        {"中文": ["默认"]},
                "原神-中文-纳西妲_ZH": {"中文": ["中立", "开心", "默认"]},
                "弗洛洛_ZH":          {"中文": ["默认"]},
            }}

        音色名是**键**，值是「语言 → 可用情绪」。所以取 keys()。
        （list 形式也一并兼容 —— 不同版本的服务端结构不一样。）

        📌 顺带记一下：这个结构说明**每种音色支持的情绪不一样**。
        纳西妲有「中立/开心」，另两个只有「默认」。当前 config.yaml 的
        emotion 是「默认」，三个音色都支持，所以现在没问题。
        但如果以后把 emotion 改成「开心」，再切到弗洛洛就可能静默失败。
        """
        client = await self._get_client()
        resp = await client.get(f"{self.base_url}/models/v4", timeout=30)
        resp.raise_for_status()
        data = resp.json()

        raw = data.get("models") if isinstance(data, dict) else data
        if isinstance(raw, dict):
            names = [str(k) for k in raw]
        elif isinstance(raw, list):
            names = [str(x) for x in raw]
        else:
            return []

        voices: list[str] = []
        for item in names:
            name = item.strip()
            if name.lower().endswith(".zip"):
                name = name[: -len(".zip")]
            # 去重时保持服务器给的顺序
            if name and name not in voices:
                voices.append(name)
        return voices

    async def probe(self) -> dict[str, Any]:
        """两步探测：服务器在不在（/version）、模型名写得对不对（/models/v4）。

        两处都可能是 GPT-SoVITS 不同版本才有的端点，所以任何一个失败
        都直接往上抛 —— health 会捕获并显示成「有探测能力但探测失败」，
        那正是用户需要看到的信号（服务没起 / 端口不对）。
        """
        client = await self._get_client()

        resp = await client.get(f"{self.base_url}/version", timeout=30)
        resp.raise_for_status()
        version = resp.json()

        resp = await client.get(f"{self.base_url}/models/v4", timeout=30)
        resp.raise_for_status()
        models = resp.json()

        # 模型列表的结构随服务器版本会变，这里做宽松匹配：
        # 只要配置的 model_name 出现在返回内容里就算匹配上。
        haystack = json.dumps(models, ensure_ascii=False)
        out: dict[str, Any] = {
            "version": version,
            "models": models,
            "model_found": bool(self.model_name) and self.model_name in haystack,
        }
        if self.model_name and not out["model_found"]:
            out["warning"] = (
                f"配置的 model_name（{self.model_name}）没有出现在 /models 返回里，"
                "请核对 config.yaml 的 tts 段里这个引擎的 model_name"
            )
        return out


# ======================================================================
# ③ 实现层：Edge-TTS（云端）
# ======================================================================

def _require_edge_tts() -> Any:
    """取 edge_tts 模块，没装就抛一句能照着做的错误。"""
    if edge_tts is None:
        raise TTSError(
            "Edge-TTS 引擎需要 edge-tts 这个包，当前环境里没有装。\n"
            "  -> 安装：pip install edge-tts\n"
            "  -> 或者把 config.yaml 的 tts.engine 改回本地引擎"
        )
    return edge_tts


@register_tts_type("edge_tts")
class EdgeTTSEngine(TTSEngine):
    """微软 Edge 朗读服务（云端）。

    定位是 GPT-SoVITS 的**对照组**，两者的取舍正好互补：

        GPT-SoVITS   本地推理 · 音色可克隆 · 约 5 秒/句（还要抢显存）
        Edge-TTS     云端服务 · 音色固定   · 首块音频不到 1 秒（需要联网）

    「没有免费午餐」在这里是具体的：要音色可控就得本地跑，
    要首段延迟低就得上云。这个对比本身就是演示时能讲的一个点。

    本机实测（2026-09）：14 字中文，首块音频 0.86 秒、全部完成 1.10 秒、
    mp3 共 21KB —— 比 GPT-SoVITS 的 wav 小一个数量级（那边同样长度约 400KB），
    所以换这个引擎顺带也是内存上的收益。
    """

    name = "edge_tts"
    label = "Edge-TTS 云端"
    audio_format = "mp3"
    base_url = "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud"
    hint = (
        "Edge-TTS 是微软的在线朗读服务，需要能访问外网。"
        "演示现场若断网，请切回本地引擎（如 GPT-SoVITS）"
    )

    def __init__(
        self,
        voice: str = "zh-CN-XiaoxiaoNeural",
        rate: str = "+0%",
        volume: str = "+0%",
        pitch: str = "+0Hz",
        timeout: float = 60.0,
        concurrency: int = 4,
        label: str = "",
    ) -> None:
        # 音色统一存进 model_name，不再另开一个 self.voice 字段。
        # 这样「当前音色」在两个引擎上都落在同一个属性上，
        # 基类 set_voice() 的默认实现（只改 model_name）对两边都成立。
        #
        # health 里那一栏本来就叫「模型」，对 Edge 来说最接近的概念也是音色。
        self.model_name = str(voice or DEFAULT_EDGE_VOICE)

        # 注意格式：这三个是 "+20%" / "-10%" / "+2Hz" 这样的**带符号字符串**，
        # 不是数字。填成 -10 会被服务端拒绝，所以统一转成字符串兜底。
        self.rate = str(rate or "+0%")
        self.volume = str(volume or "+0%")
        self.pitch = str(pitch or "+0Hz")
        self.timeout = float(timeout)
        # 坑：edge-tts 7.x 要求 receive_timeout 是 **int**。
        # 传 float（哪怕 60.0）不会在构造时报错，而是在**流式迭代**里才抛
        # "receive_timeout must be int" —— 也就是每一句合成都会失败，
        # 但错误信息完全看不出是超时参数的问题。配置里人很容易写成 60.0。
        self._receive_timeout = max(1, int(round(self.timeout)))
        # 云端服务不抢本地显存，也没有 GPT-SoVITS 那种并发即降速的问题，
        # 可以放开。播放顺序仍由 index 保证，调大只影响「音频到得多快」。
        self.concurrency = max(1, int(concurrency))
        if label:
            self.label = label

    @classmethod
    def from_config(cls, section: dict[str, Any]) -> "EdgeTTSEngine":
        # 把「没装包」这个错误提前到构造期，这样它会在 /api/options
        # 里直接显示成「不可用」+ 原因，而不是等用户点了发送才炸。
        _require_edge_tts()
        return super().from_config(section)

    async def synthesize(self, text: str) -> bytes:
        """合成一句，返回 mp3 字节。

        注意：Edge 的服务**内部**确实是流式返回的（边算边推 chunk），
        但接口粒度仍然是「整句进、整段出」。
        所以和 GPT-SoVITS 一样属于逐句合成，别说成「逐字流式语音」。
        """
        api = _require_edge_tts()

        communicate = api.Communicate(
            text,
            self.model_name,
            rate=self.rate,
            volume=self.volume,
            pitch=self.pitch,
            receive_timeout=self._receive_timeout,
        )

        buffer = bytearray()
        try:
            async for chunk in communicate.stream():
                if chunk.get("type") == "audio":
                    buffer += chunk["data"]
        except Exception as exc:  # noqa: BLE001
            raise TTSError(
                f"Edge-TTS 合成失败（voice={self.model_name!r}, rate={self.rate!r}）：{exc}\n"
                "  -> 最常见原因是网络不通（这是微软的在线服务），"
                "或音色名写错。可用音色见 /api/options 里的 tts.voices。"
            ) from exc

        if not buffer:
            raise TTSError(
                f"Edge-TTS 没有返回任何音频（voice={self.model_name!r}）。\n"
                "  -> 通常是音色名不存在，跑 `edge-tts --list-voices` 可以看到全部可用音色。"
            )
        return bytes(buffer)

    async def list_voices(self) -> list[str]:
        """微软的音色列表，只留中文的 —— 这个演示是中文对话。

        数量不少（十来个），前端会做成下拉框，不影响。
        """
        api = _require_edge_tts()
        voices = await api.list_voices()
        return sorted(
            str(v.get("ShortName"))
            for v in voices
            if str(v.get("Locale", "")).startswith("zh")
        )

    async def probe(self) -> dict[str, Any]:
        """真合成一句短文本。

        这是唯一能同时验证「网络通不通」和「音色名合不合法」的办法 ——
        只 ping 一个端点是不够的，鉴权和音色校验发生在合成请求里。
        """
        api = _require_edge_tts()
        audio = await self.synthesize("你好")

        out: dict[str, Any] = {
            "version": f"edge-tts {getattr(api, '__version__', '?')}",
            "model_found": True,
            "probe_audio_bytes": len(audio),
        }
        try:
            zh = await self.list_voices()
            out["models"] = zh
            out["model_found"] = self.model_name in zh
            if zh and not out["model_found"]:
                out["warning"] = (
                    f"配置的 voice（{self.model_name}）不在可用中文音色列表里，"
                    "合成可能会失败。可用：" + "、".join(zh[:6])
                )
        except Exception:  # noqa: BLE001
            # 拿不到音色列表不影响可用性判断 —— 上面已经真合成成功一句了。
            out.setdefault("models", [])
        return out


# ======================================================================
# 工厂
# ======================================================================

def _engine_section(tts_cfg: dict[str, Any], engine_name: str) -> dict[str, Any]:
    """取出某个引擎的配置小节。

    两种写法都支持：

      分段式（推荐）
          tts:
            engine: gptsovits
            gptsovits: {type: gptsovits, base_url: ..., ...}
            edge:      {type: edge_tts,  voice: ..., ...}

      扁平式（旧配置，仍然可用）
          tts:
            engine: gptsovits
            base_url: ...
            model_name: ...
        —— 找不到以段名命名的子字典时，就把整个 tts 段当成那唯一一个引擎的小节，
        type 取 engine 的值。这样老的 config.yaml 不用改就能继续跑。
    """
    section = tts_cfg.get(engine_name)
    if isinstance(section, dict) and section:
        return dict(section)

    legacy = {k: v for k, v in tts_cfg.items() if k not in SHARED_TTS_KEYS}
    legacy.setdefault("type", engine_name)
    return legacy


def list_tts_engines() -> list[str]:
    """config.yaml 的 tts 段里定义了哪些引擎（返回段名）。供 /api/options 用。"""
    cfg = load_config()
    tts_cfg = cfg.get("tts") or {}
    names = [
        str(key)
        for key, value in tts_cfg.items()
        if isinstance(value, dict) and value and key not in SHARED_TTS_KEYS
    ]
    if not names:
        # 扁平式的旧配置：只有一个引擎，名字来自 tts.engine
        return [str(tts_cfg.get("engine") or "gptsovits")]
    return sorted(names)


def create_tts_engine(name: str | None = None) -> TTSEngine:
    """工厂：按 config.yaml 的 tts 段创建 TTS 引擎。

    :param name: 指定用哪个引擎（如 "edge"）。None 则用运行时切换层的当前值，
                 再回退到 config.yaml 的 tts.engine。

    加新引擎不需要改这个函数 —— 它按小节里的 type 字段查注册表。
    """
    cfg = load_config()
    tts_cfg = cfg.get("tts") or {}

    engine_name = (name or resolve_tts_name() or "gptsovits").strip().lower()
    section = _engine_section(tts_cfg, engine_name)

    type_name = str(section.get("type") or engine_name).strip().lower()
    cls = _TTS_TYPES.get(type_name)
    if cls is None:
        known = ", ".join(available_tts_types()) or "（无）"
        raise TTSError(
            f"未知的 TTS 引擎类型：{type_name!r}（配置里的段名是 {engine_name!r}）。\n"
            f"  已注册的引擎类型：{known}\n"
            "  -> config.yaml 里该小节的 type 要填上面某一个；\n"
            "  -> 想在没装 GPT-SoVITS 的机器上跑通全链路，可以运行 "
            "tts_server_mock.py，再把该小节的 base_url 指过去。"
        )

    # base_url 里的 ${VAR} 没解析出值时，给一句比「连不上」有用得多的提示。
    # 云端引擎的地址是内置常量、不走配置，所以这里取不到值也不报错。
    base_url = str(section.get("base_url") or "")
    hint = missing_env_hint(base_url, f"tts.{engine_name}.base_url")
    if hint:
        raise TTSError(hint)

    engine = cls.from_config(section)

    # 运行时选过的音色优先（按引擎分别记，见 runtime.py）。
    # 放在构造之后而不是塞进 section：这样引擎自己的默认值和兜底逻辑
    # 仍然按配置走，覆盖只是最后一步覆盖上去。
    #
    # 音色的生效优先级是**三层**：
    #     用户手选  >  当前人格绑定的音色  >  config.yaml 里该引擎的 voice
    # 两者分开查是刻意的 —— 「用户点回默认音色」只清用户那层，
    # 人格绑的音色会重新露出来，不会一起被清掉（见 runtime._persona_voices）。
    #
    # 注意这里**只做查表**，不校验音色是否存在：校验在 /api/switch 里做
    # （那里能返回 400 给用户看）。这一层要是自己校验，就得每轮多一次
    # list_voices() 网络往返，而它换来的只是「换个方式静默失败」。
    voice = resolve_tts_voice(engine_name) or resolve_persona_voice(engine_name)
    if voice:
        engine.set_voice(voice)

    logger.info(
        "已创建 TTS 引擎：段名=%s type=%s 音色=%s format=%s concurrency=%d",
        engine_name,
        engine.name,
        engine.model_name,
        engine.audio_format,
        engine.concurrency,
    )
    return engine


def get_split_config() -> tuple[list[str], int]:
    """从配置里读出分句参数，供 main.py 使用。"""
    cfg = load_config()
    tts_cfg = cfg.get("tts") or {}
    delimiters = tts_cfg.get("delimiters") or list(DEFAULT_DELIMITERS)
    max_chars = int(tts_cfg.get("max_chars", DEFAULT_MAX_CHARS))
    return [str(d) for d in delimiters], max_chars
