# -*- coding: utf-8 -*-
"""
工具（Function Calling）
========================
让模型能**主动决定**去查一次外部信息，再把结果拿回来接着回答。

    LLM 第一轮 ──► 吐出 tool_calls（"我要查天气，城市=北京"）
                      │
                      ▼
              后端执行 get_weather("北京")   ← 这个文件
                      │
                      ▼
    LLM 第二轮 ──► 拿到天气结果，用自然语言回答（这句才拿去合成语音）

设计要点（三条都是被坑出来的，改动前请先读）：

1. **`execute_tool()` 永不抛异常。**
   官方 SDK 的文档自己写着「模型不总是生成合法 JSON，还可能幻觉出 schema
   里没有的参数」（见 openai/types/chat/chat_completion_chunk.py 的
   ChoiceDeltaToolCallFunction.arguments 注释）。抛异常会打断整轮对话，
   而**返回一句错误字符串**的话，模型能看见错误、自己纠正或者如实告诉用户。
   未知工具 / JSON 坏掉 / 参数名对不上 / 超时 / 工具内部炸了 —— 全部走这条路。

2. **`calculate` 用 AST 白名单求值，绝不用 `eval`。**
   表达式是**模型生成的**，而模型可能被用户诱导产出任意 Python。
   `eval("__import__('os').system('...')")` 是真实存在的攻击面，不是理论风险。
   白名单只放行数字字面量和四则运算节点，属性访问、函数调用、变量名一律拒绝。

3. **`**` 的指数要单独设上限。**
   `9**9**9` 只需要十几个字符，却会让 CPython 算到世界末日（内存与 CPU 双双爆掉）。
   表达式长度限制挡不住它，必须单独限制指数大小。

注册表沿用 tts_client.py 的套路：写个函数、打个装饰器，就在 config.yaml 里能引用了。
"""
from __future__ import annotations

import ast
import asyncio
import inspect
import json
import logging
import math
import operator
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Callable
from urllib.parse import quote

import httpx

from .config import load_config

logger = logging.getLogger(__name__)

#: chip 上显示的说明最长多少个字，超了截断
SUMMARY_MAX_CHARS = 40

#: 算数表达式最长多少个字符
MAX_EXPRESSION_CHARS = 200

#: `**` 的指数绝对值上限。见模块 docstring 第 3 条
MAX_POW_EXPONENT = 64

#: 工具的默认超时（秒），可被 config.yaml 的 tools.timeout 覆盖。
#: 刻意压得比较短：这段时间用户是**盯着打字指示器干等**的，
#: 一个查天气卡 15 秒比直接告诉模型「查不到」糟糕得多。
DEFAULT_TOOL_TIMEOUT = 8.0

#: 一轮里最多执行几个工具调用。模型（尤其小模型）有时会一口气吐出几十个，
#: 不设上限就是几十次串行的网络请求，而用户只看到指示器一直在转
MAX_TOOL_CALLS_PER_ROUND = 4

#: wttr.in 要带一个像样的 User-Agent，否则会被拒
WEATHER_USER_AGENT = "curl/8.0"
WEATHER_URL = "https://wttr.in/{city}"


class _ToolError(ValueError):
    """工具层的**可预期**错误（参数不对、结果不合理）。

    刻意与「工具内部真的炸了」区分开：这一类的措辞是给模型看的，
    说明「你给的东西不对」，好让它换个参数重试。
    """


@dataclass(frozen=True)
class ToolResult:
    """一次工具调用的结果。

    ⚠ 为什么要有 `ok` 这个布尔值，而不是「失败就返回一段以『调用失败』开头的
    字符串、让调用方去猜」：**界面上的 chip 要能区分「查到了」和「没查到」**。

    没有这个标志的话，断网时 `get_weather` 每次都失败、每次把错误串喂给模型，
    而 chip 照样显示一个绿色的「完成」—— 坏掉的工具和好用的工具长得一模一样。
    讲稿里「完全断网」是写进应急预案的场景，那时候观众看到的必须能说明问题。
    显式的布尔值让这个区分在类型上就成立，不靠字符串约定。
    """

    ok: bool
    text: str

    def __str__(self) -> str:  # 方便直接当字符串用
        return self.text


# ======================================================================
# 注册表
# ======================================================================

@dataclass(frozen=True)
class ToolSpec:
    """一个工具的完整描述：给模型看的 schema + 真正干活的函数。"""

    name: str
    #: 界面上显示的中文名（如「查天气」），会随 tool 事件发给前端
    label: str
    #: 给模型看的用途说明。tool_choice="auto" 时模型**就是靠这段文字**
    #: 决定要不要调用、什么时候调用，所以要写清楚「什么时候该用它」
    description: str
    #: JSON Schema，描述参数
    parameters: dict[str, Any]
    func: Callable[..., Any]
    #: (参数, 结果) -> chip 上那一行短说明。result 为 None 表示还在执行中
    summarize: Callable[[dict[str, Any], str | None], str]


_TOOLS: dict[str, ToolSpec] = {}


def _default_summarize(args: dict[str, Any], result: str | None) -> str:
    """没提供 summarize 时的兜底：执行中显示参数，完成后显示结果。"""
    if result is None:
        return _short(", ".join(f"{v}" for v in args.values()))
    return _short(result)


def register_tool(
    *,
    name: str,
    label: str,
    description: str,
    parameters: dict[str, Any],
    summarize: Callable[[dict[str, Any], str | None], str] | None = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """把一个函数注册成模型可调用的工具。

    用法（和 tts_client 的 @register_tts_type 同构）::

        @register_tool(name="get_weather", label="查天气", description="...",
                       parameters={...})
        async def get_weather(city: str) -> str: ...
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        key = name.strip().lower()
        if key in _TOOLS:
            raise ValueError(f"工具 {key!r} 已经注册过了")
        _TOOLS[key] = ToolSpec(
            name=key,
            label=label,
            description=description,
            parameters=parameters,
            func=func,
            summarize=summarize or _default_summarize,
        )
        return func

    return decorator


def list_tools() -> list[str]:
    """已注册的工具名（排序，好让报错信息稳定）。"""
    return sorted(_TOOLS)


def get_tool(name: str) -> ToolSpec | None:
    """按名字取工具。名字大小写不敏感（模型有时会把大小写写歪）。"""
    return _TOOLS.get(str(name or "").strip().lower())


def _short(text: Any, limit: int = SUMMARY_MAX_CHARS) -> str:
    """压成一行并截断 —— chip 上放不下换行和长文本。"""
    flat = " ".join(str(text).split())
    return flat if len(flat) <= limit else f"{flat[:limit]}…"


# ======================================================================
# 配置
# ======================================================================

def _tools_section() -> dict[str, Any]:
    section = load_config().get("tools") or {}
    return section if isinstance(section, dict) else {}


def configured_tool_names() -> list[str]:
    """config.yaml 的 tools.available 里列了哪些工具。

    没写这一项就返回**全部**已注册的工具 —— 少写一行配置不该让功能静默消失。
    """
    raw = _tools_section().get("available")
    if not isinstance(raw, list):
        return list_tools()
    return [str(n).strip().lower() for n in raw if str(n).strip()]


def resolve_max_rounds() -> int:
    """一轮对话里最多允许几轮「模型要求调工具 → 我们回灌结果」。

    必须设上限：模型有可能一直要求调工具不停下来（尤其小模型），
    没有上限就是一个死循环，而且是在演示现场慢慢把资源耗光。
    """
    try:
        value = int(_tools_section().get("max_rounds", 4))
    except (TypeError, ValueError):
        return 4
    return max(1, min(value, 10))


def resolve_timeout() -> float:
    """单个工具的执行超时（秒）。"""
    try:
        value = float(_tools_section().get("timeout", DEFAULT_TOOL_TIMEOUT))
    except (TypeError, ValueError):
        return DEFAULT_TOOL_TIMEOUT
    return max(1.0, value)


def instance_tools_enabled(instance_name: str) -> bool:
    """这个 LLM 实例有没有打开工具调用（config.yaml 的 llm.<名字>.tools）。

    **按实例开关是刻意的**：不同模型对 function calling 的支持差别很大，
    不支持的工具收到 tools 参数时轻则忽略、重则直接报错。
    默认关闭 —— 要显式写 `tools: true` 才开。
    """
    section = (load_config().get("llm") or {}).get(str(instance_name or ""))
    if not isinstance(section, dict):
        return False
    return bool(section.get("tools"))


def build_tool_definitions(names: Sequence[str] | None = None) -> list[dict[str, Any]]:
    """拼出 OpenAI 协议要的 tools 参数。

    形状见 openai/types/shared_params/function_definition.py：
    ``[{"type": "function", "function": {name, description, parameters}}]``
    """
    selected = [str(n).strip().lower() for n in names] if names is not None else configured_tool_names()
    definitions: list[dict[str, Any]] = []
    for name in selected:
        spec = _TOOLS.get(name)
        if spec is None:
            # 配置里写了个不存在的工具：跳过但要说出来，
            # 否则「配了却没生效」会变成一个没人发现的静默失败
            logger.warning("config.yaml 里启用了未注册的工具 %r，已跳过。已注册：%s", name, list_tools())
            continue
        definitions.append(
            {
                "type": "function",
                "function": {
                    "name": spec.name,
                    "description": spec.description,
                    "parameters": spec.parameters,
                },
            }
        )
    return definitions


# ======================================================================
# 具体工具
# ======================================================================

# ---- 算数 ----

_ALLOWED_BINOPS: dict[type[ast.operator], Callable[[Any, Any], Any]] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}

_ALLOWED_UNARYOPS: dict[type[ast.unaryop], Callable[[Any], Any]] = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}


def _eval_node(node: ast.AST) -> Any:
    """在白名单里递归求值。任何不在白名单里的节点直接拒绝。"""
    if isinstance(node, ast.Expression):
        return _eval_node(node.body)

    if isinstance(node, ast.Constant):
        # bool 是 int 的子类，得先挡掉 —— True 当数字算没有意义，
        # 而且说明模型理解错了这个工具是干嘛的
        if isinstance(node.value, bool) or not isinstance(node.value, (int, float)):
            raise _ToolError("表达式里只能有数字，不能有文字或布尔值")
        return node.value

    if isinstance(node, ast.BinOp):
        op = _ALLOWED_BINOPS.get(type(node.op))
        if op is None:
            raise _ToolError(f"不支持这个运算符：{type(node.op).__name__}")
        left = _eval_node(node.left)
        right = _eval_node(node.right)
        if op is operator.pow and abs(right) > MAX_POW_EXPONENT:
            # 见模块 docstring 第 3 条。9**9**9 会让进程直接挂住
            raise _ToolError(f"指数太大了（上限 {MAX_POW_EXPONENT}）")
        return op(left, right)

    if isinstance(node, ast.UnaryOp):
        op = _ALLOWED_UNARYOPS.get(type(node.op))
        if op is None:
            raise _ToolError(f"不支持这个单目运算符：{type(node.op).__name__}")
        return op(_eval_node(node.operand))

    # 函数调用、属性访问（__class__ / __globals__ …）、下标、变量名……
    # 全部落在这里。**这个兜底就是安全边界**，不要为了「支持更多写法」放宽它
    raise _ToolError(f"表达式里不允许出现 {type(node).__name__}")


def _weather_summary(args: dict[str, Any], result: str | None) -> str:
    # 执行中只显示城市名；完成后 result 里已经带了城市名，不用再拼一遍
    if result is None:
        return _short(args.get("city", ""), 20)
    return _short(result, 40)


def _calc_summary(args: dict[str, Any], result: str | None) -> str:
    expr = _short(args.get("expression", ""), 30)
    return expr if result is None else f"{expr} = {_short(result, 20)}"


def _time_summary(args: dict[str, Any], result: str | None) -> str:
    return "现在" if result is None else _short(result, 30)


@register_tool(
    name="calculate",
    label="算数",
    description=(
        "计算一个数学表达式并返回精确结果。当用户的问题涉及具体的数字运算"
        "（加减乘除、乘方、取余、整除）时使用它，不要自己心算。"
        "表达式只支持数字和 + - * / // % ** 以及括号。"
    ),
    parameters={
        "type": "object",
        "properties": {
            "expression": {
                "type": "string",
                "description": "要计算的数学表达式，例如 (3 + 5) * 2 或 2 ** 10",
            }
        },
        "required": ["expression"],
    },
    summarize=_calc_summary,
)
def calculate(expression: str) -> str:
    """用 AST 白名单求值 —— 不是 eval。见模块 docstring 第 2 条。"""
    text = str(expression or "").strip()
    if not text:
        raise _ToolError("表达式是空的")
    if len(text) > MAX_EXPRESSION_CHARS:
        raise _ToolError(f"表达式太长了（上限 {MAX_EXPRESSION_CHARS} 个字符）")

    try:
        tree = ast.parse(text, mode="eval")
    except SyntaxError as exc:
        raise _ToolError(f"表达式语法有误：{exc.msg}") from exc

    try:
        value = _eval_node(tree)
    except ZeroDivisionError:
        # 除以零是**模型可能犯的正常错误**，不是我们的 bug。
        # 归到 _ToolError 而不是让它冒到 execute_tool 的兜底分支：
        # 后者会 logger.warning(exc_info=True) 打一整段堆栈，
        # 演示现场终端里刷一片红字，看着像程序坏了。
        raise _ToolError("除数不能为零") from None
    except ArithmeticError as exc:
        raise _ToolError(f"算不出来：{exc}") from exc

    if isinstance(value, float) and not math.isfinite(value):
        raise _ToolError("计算结果不是有限数")
    # 4.0 显示成 4 更像人话，也更容易被 TTS 念对
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    return str(value)


@register_tool(
    name="current_time",
    label="查时间",
    description=(
        "获取当前的本地日期和时间。当用户问到「现在几点」「今天几号」「今天星期几」"
        "这类问题时使用它 —— 你自己的知识里没有当前时间。"
    ),
    parameters={"type": "object", "properties": {}},
    summarize=_time_summary,
)
def current_time() -> str:
    """纯本地，零外部依赖。断网也能用 —— 这是刻意的演示兜底。"""
    now = datetime.now()
    weekday = "一二三四五六日"[now.weekday()]
    return f"{now:%Y-%m-%d %H:%M:%S} 星期{weekday}"


@register_tool(
    name="get_weather",
    label="查天气",
    description=(
        "查询某个城市当前的天气。当用户问到某个地方的天气、气温、阴晴雨雪时使用它。"
        "不要在用户没提到地点时猜一个城市。"
    ),
    parameters={
        "type": "object",
        "properties": {
            "city": {
                "type": "string",
                "description": "城市名，中英文都可以，例如 北京 或 Tokyo",
            }
        },
        "required": ["city"],
    },
    summarize=_weather_summary,
)
async def get_weather(city: str) -> str:
    """走 wttr.in（免费、无需 key）。

    ⚠ 需要联网。断网时这里会抛异常，由 execute_tool() 转成错误字符串返回给模型，
    整轮对话不受影响 —— 这是刻意的：语音和文字都不该因为一个工具连不上就断掉。

    刻意用 format=j1（JSON）而不是 format="%C %t" 那种一行格式：
    一行格式里的天气描述**永远是英文**（"Smoky haze"），而这个字符串是要
    送进 TTS 朗读的 —— 中文模型念英文短语会念得很难听。
    中文描述只在 JSON 的 current_condition[0].lang_zh 里。
    """
    name = str(city or "").strip()
    if not name:
        raise _ToolError("城市名是空的")
    if len(name) > 60:
        raise _ToolError("城市名太长了")

    timeout = resolve_timeout()
    # 中文城市名必须 quote —— 直接拼进 URL 会得到 400
    url = WEATHER_URL.format(city=quote(name))
    async with httpx.AsyncClient(timeout=timeout) as client:
        resp = await client.get(
            url,
            params={"format": "j1", "lang": "zh"},
            headers={"User-Agent": WEATHER_USER_AGENT},
        )
        resp.raise_for_status()
        try:
            data = resp.json()
        except ValueError as exc:
            raise _ToolError("天气服务返回的不是 JSON，可能是城市名没被识别") from exc

    return _format_weather(name, data)


def _first_value(items: Any) -> str | None:
    """wttr.in 的 JSON 里满是 [{"value": "..."}] 这种嵌套，取值的样板代码。"""
    if not isinstance(items, list) or not items:
        return None
    head = items[0]
    if not isinstance(head, dict):
        return None
    value = head.get("value")
    return str(value) if value is not None else None


# ----------------------------------------------------------------------
# 天气现象的中英对照
# ----------------------------------------------------------------------
# ⚠ 为什么需要这张表：wttr.in 的 `lang=zh` 参数**实测根本没生效**。
# 2026-09 实跑北京/上海/广州/成都/伦敦/东京/纽约/悉尼/莫斯科/开罗，
# 返回的 lang_zh 和 weatherDesc 逐字相同，全是英文（"Smoky haze"、
# "Patchy rain nearby"……）。也就是说那个字段只是个别名，不是译文。
#
# 而这些描述是要**送进 TTS 朗读**的 —— 中文音色念 "Patchy rain nearby"
# 会念得支离破碎。所以译文只能自己带。
#
# 先精确匹配（覆盖 wttr.in 实际会吐的那些固定说法），
# 匹配不上再按关键词兜底，最后才退回原文（宁可英文，也不要空着）。
_WEATHER_ZH: dict[str, str] = {
    "sunny": "晴",
    "clear": "晴",
    "partly cloudy": "多云",
    "cloudy": "多云",
    "overcast": "阴",
    "mist": "薄雾",
    "fog": "雾",
    "freezing fog": "冻雾",
    "haze": "霾",
    "smoky haze": "烟霾",
    "light drizzle": "小雨",
    "freezing drizzle": "冻毛毛雨",
    "light rain": "小雨",
    "moderate rain": "中雨",
    "heavy rain": "大雨",
    "light rain shower": "阵雨",
    "moderate or heavy rain shower": "强阵雨",
    "torrential rain shower": "暴雨",
    "patchy rain nearby": "局部有雨",
    "patchy rain possible": "可能有雨",
    "light freezing rain": "冻雨",
    "moderate or heavy freezing rain": "强冻雨",
    "light sleet": "小雨夹雪",
    "moderate or heavy sleet": "雨夹雪",
    "light snow": "小雪",
    "moderate snow": "中雪",
    "heavy snow": "大雪",
    "blowing snow": "风吹雪",
    "blizzard": "暴风雪",
    "patchy snow nearby": "局部有雪",
    "light snow showers": "阵雪",
    "moderate or heavy snow showers": "强阵雪",
    "thundery outbreaks possible": "可能有雷雨",
    "patchy light rain with thunder": "雷阵雨",
    "moderate or heavy rain with thunder": "强雷雨",
    "patchy light snow with thunder": "雷阵雪",
    "light showers of ice pellets": "小冰粒",
    "moderate or heavy showers of ice pellets": "强冰粒",
}

#: 顺序有意义：「thunder」必须排在「rain」前面，否则「雷阵雨」会被判成「雨」
_WEATHER_KEYWORDS: tuple[tuple[str, str], ...] = (
    ("thunder", "雷阵雨"),
    ("blizzard", "暴风雪"),
    ("sleet", "雨夹雪"),
    ("ice pellet", "冰粒"),
    ("snow", "雪"),
    ("drizzle", "毛毛雨"),
    ("rain", "雨"),
    ("freezing", "冻"),
    ("fog", "雾"),
    ("mist", "薄雾"),
    ("haze", "霾"),
    ("overcast", "阴"),
    ("cloud", "多云"),
    ("sunny", "晴"),
    ("clear", "晴"),
)


def _translate_condition(text: str) -> str:
    """把英文天气描述转成中文。认不出来就原样返回（有总比没有强）。"""
    raw = str(text or "").strip()
    if not raw:
        return ""
    key = " ".join(raw.split()).lower()

    exact = _WEATHER_ZH.get(key)
    if exact:
        return exact
    for needle, zh in _WEATHER_KEYWORDS:
        if needle in key:
            return zh
    return raw


def _format_weather(city: str, data: Any) -> str:
    """把 wttr.in 的 JSON 压成一句口语化的中文，方便直接朗读。"""
    if not isinstance(data, dict):
        raise _ToolError("天气服务的返回格式不认识")

    current = data.get("current_condition")
    if not isinstance(current, list) or not current or not isinstance(current[0], dict):
        raise _ToolError("天气服务没有返回当前天气")

    now = current[0]
    desc = _translate_condition(
        _first_value(now.get("lang_zh")) or _first_value(now.get("weatherDesc")) or ""
    )

    parts: list[str] = []
    if desc:
        parts.append(desc)
    if now.get("temp_C") is not None:
        parts.append(f"{now['temp_C']} 摄氏度")
    if now.get("FeelsLikeC") is not None and now.get("FeelsLikeC") != now.get("temp_C"):
        parts.append(f"体感 {now['FeelsLikeC']} 度")
    if now.get("humidity") is not None:
        parts.append(f"湿度 {now['humidity']}%")
    if now.get("windspeedKmph") is not None:
        parts.append(f"风速 {now['windspeedKmph']} 公里每小时")

    if not parts:
        raise _ToolError("天气服务返回的内容是空的")
    return f"{city}：{'，'.join(parts)}"


# ======================================================================
# 执行
# ======================================================================

def _parse_arguments(raw: Any) -> dict[str, Any]:
    """把模型给的参数解析成 dict。失败一律抛 _ToolError（由调用方转成字符串）。"""
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        # 无参工具（比如 current_time）模型会发空串或者干脆不带
        return {}
    if isinstance(raw, dict):
        return raw
    if not isinstance(raw, str):
        raise _ToolError(f"参数格式不对：期望 JSON 字符串，收到 {type(raw).__name__}")

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise _ToolError(f"参数不是合法 JSON：{exc}") from exc

    if not isinstance(parsed, dict):
        raise _ToolError(f"参数必须是 JSON 对象，收到 {type(parsed).__name__}")
    return parsed


async def execute_tool(name: str, arguments: Any) -> ToolResult:
    """执行一个工具，**永远返回 ToolResult、永远不抛 Exception**。

    :param name: 工具名（模型给的）
    :param arguments: 工具参数，通常是模型的 JSON 字符串；也接受已解析好的 dict

    失败时的 text 是**给模型看的**错误说明，不是给用户看的 ——
    模型看到之后可以换个参数重试，或者如实告诉用户「我查不到」。
    见模块 docstring 第 1 条。

    ⚠ **`CancelledError` 必须放行，不能被这里的任何 except 吞掉。**
    用户点「停止生成」时 `_run_turn` 整个任务被 cancel，取消信号就是通过
    `CancelledError` 传进来的。它是 `BaseException` 的子类（3.8+），
    所以下面这些 `except Exception` **天然不会**接住它 ——
    这是刻意的，不要为了「更周全」改成 `except BaseException`。
    改了会怎样：停止生成变成一次「工具调用失败」，模型于是拿着这句错误
    又开了一轮，`ws_chat.stop_current()` 还 await 着这个任务，
    整条接收循环被堵住 —— 用户按了停止，模型反而继续说，而且新消息发不出去。
    同理，`asyncio.wait_for` 的超时也是靠取消实现的，吞掉取消信号超时就失效了。
    """
    spec = get_tool(name)
    if spec is None:
        available = "、".join(list_tools()) or "（无）"
        return ToolResult(False, f"调用失败：没有名为 {name!r} 的工具。可用的工具：{available}")

    try:
        args = _parse_arguments(arguments)
    except _ToolError as exc:
        return ToolResult(False, f"「{spec.label}」调用失败：{exc}")

    timeout = resolve_timeout()
    try:
        result = spec.func(**args)
        if inspect.isawaitable(result):
            # 超时必须在这里兜住：httpx 不设总超时的话，对方不响应会一直挂着，
            # 而用户那边只看到「卡住了」
            result = await asyncio.wait_for(result, timeout=timeout)
    except asyncio.TimeoutError:
        logger.warning("工具 %s 执行超时（%.0f 秒）", spec.name, timeout)
        return ToolResult(False, f"「{spec.label}」执行超时（超过 {timeout:.0f} 秒）")
    except _ToolError as exc:
        # 可预期错误：参数不对、结果不合理。措辞留给模型去纠正
        return ToolResult(False, f"「{spec.label}」调用失败：{exc}")
    except TypeError as exc:
        # 多半是模型幻觉出了 schema 里没有的参数名
        return ToolResult(
            False, f"「{spec.label}」的参数不对：{exc}（允许的参数：{_param_names(spec)}）"
        )
    except Exception as exc:  # noqa: BLE001 - 工具炸了不该拖垮整轮对话
        logger.warning("工具 %s 执行失败：%s", spec.name, exc, exc_info=True)
        return ToolResult(False, f"「{spec.label}」执行失败：{type(exc).__name__}: {exc}")

    return ToolResult(True, str(result))


def _param_names(spec: ToolSpec) -> str:
    props = spec.parameters.get("properties")
    if not isinstance(props, dict) or not props:
        return "无"
    return "、".join(str(k) for k in props)
