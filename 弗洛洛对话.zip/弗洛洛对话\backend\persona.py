# -*- coding: utf-8 -*-
"""人格（角色）提示词：加载、清洗、和通用规则组装。
=====================================================================

人格是继 LLM 实例、TTS 引擎之后的**第三个可插拔维度**，
形状和那两个一样：config.yaml 里 `persona.current` 选一个，
下面每个人格一个小节，`backend/runtime.py` 记运行时覆盖。

和另外两个维度不同的一点：提示词正文放在 `personas/*.txt`，
**不在 config.yaml 里**，而且这里**不缓存** —— 所以改提示词不用重启后端，
下一轮对话就生效。（config.yaml 是 lru_cache 的，改它要重启。）

--------------------------------------------------------------
⚠ 最重要的一条：这个模块里**读文件一律 fail-soft，绝不抛异常**
--------------------------------------------------------------

不是「顺手写得防御一点」，是因为抛出去的后果特别严重：

  main.py 的 `_build_messages()` 调用点在 try **之外**（_run_turn 开头），
  异常会直接穿出 `_run_turn()`。而它是被 `asyncio.create_task()` 起的，
  没人 await 那个任务 → 异常被吞进日志（只有一句
  "Task exception was never retrieved"）→ **一个 WebSocket 帧都发不出去**。
  前端 `isGenerating` 只由 done/error 帧复位，于是它**永久为 true**：
  发送键一直是灰的，点「停止生成」也没用（后端见任务已结束就不回帧了），
  页面上没有任何文字解释 —— **只能刷新页面**。
  这正是这个项目一直在防的那种「看起来像整个应用死了」。

更糟的是它还会污染验证工具：`_attach_live_e2e.py` 和 `_tools_check.py`
都直接驱动 `_run_turn()`，人格抛异常会让它们收到空帧 ——
附件探针会把「人格文件读不到」报告成「每个模型都读不出图」。

所以分工是：

  · 本模块的读取路径 —— 出错就 logger.warning + 退化成「没有角色」，
    **绝不抛**。宁可少一个人设，也不能让页面假死。
  · 硬校验（人格名不存在、文件越界）—— 放在 `/api/switch` 里，
    当场 400 拒绝并说明原因。那里是用户主动操作的路径，报错看得见。

`config.py:_parse_env_file()` 的 `try: read_text() except OSError` 就是这个风格。
"""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

from .config import PROJECT_ROOT, load_config

logger = logging.getLogger(__name__)

#: 人格提示词目录。和 config.py 的 CONFIG_PATH、main.py 的 FRONTEND_DIST_DIR
#: 一样硬编码在 PROJECT_ROOT 下 —— 不做成配置项，免得引入「相对谁解析 /
#: cwd 对不对 / 路径越界」一整类问题。
PERSONAS_DIR = PROJECT_ROOT / "personas"

#: 生成这些提示词时残留的引用标记，形如 [reference:0]。
#: 对模型是噪声，而且**可能被复述出来送去 TTS 朗读**，所以要清掉。
#: 用 `\d+` 就够：形如 [reference:3][reference:4] 的相邻形态会被连续替换掉。
_REFERENCE_MARK = re.compile(r"\[reference:\d+\]")

#: 角色提示词和通用规则之间的分隔语。
#: 特意说明是**回答形式**上的要求 —— 素材正文本身是 Markdown 排版的
#: （带 `#` 和 `**`），不划清界限的话模型有概率跟着模仿那种排版，
#: 而通用规则里明确要求「不要 Markdown」（因为回答要被朗读出来）。
_BRIDGE = "以上是你的身份设定。以下是**回答形式**上的要求（与身份无关），必须遵守："


class PersonaError(RuntimeError):
    """人格配置有问题。

    ⚠ 只在 `/api/switch` 那种「用户主动操作」的校验路径上抛（转成 400）。
    **读取路径永远不要抛这个** —— 见模块开头的说明。
    """


# ======================================================================
# 读配置
# ======================================================================

def _persona_section() -> dict[str, Any]:
    """config.yaml 的 persona 段（拿不到就空 dict）。"""
    section = load_config().get("persona") or {}
    return section if isinstance(section, dict) else {}


def _role_section(name: str | None) -> dict[str, Any]:
    """单个人格的小节。

    注意过滤方式：和 `llm.provider` / `tts.engine` 那两个标量一样，
    `current` 之类不是 dict 的键会被自动排除掉。
    """
    key = str(name or "").strip()
    if not key:
        return {}
    value = _persona_section().get(key)
    return value if isinstance(value, dict) else {}


def list_persona_names() -> list[str]:
    """config.yaml 里定义了哪些人格（不含 current 这类标量键）。"""
    return sorted(
        key for key, value in _persona_section().items() if isinstance(value, dict)
    )


def require_persona(name: str) -> dict[str, Any]:
    """取一个人格的小节；不存在就抛出**给人看**的错误。

    只给 `/api/switch` 用 —— 那里 400 出去的错误信息会直接显示在页面上，
    所以要能照着修（列出可选值）。
    """
    key = str(name or "").strip()
    section = _role_section(key)
    if not section:
        known = list_persona_names()
        raise PersonaError(
            f"config.yaml 里找不到人格 {key!r}。\n"
            f"  当前已定义的人格：{'、'.join(known) if known else '（无）'}"
        )
    return section


def persona_file_path(name: str) -> Path | None:
    """人格提示词文件的绝对路径。配置缺失或**越界**就返回 None。

    越界检查是必要的：`file` 是配置里的字符串，写个 `../../.env`
    就会把别处的文件读进 system prompt。解析成绝对路径后确认它**确实**
    在 PERSONAS_DIR 里面。
    """
    file_name = str(_role_section(name).get("file") or "").strip()
    if not file_name:
        return None
    try:
        path = (PERSONAS_DIR / file_name).resolve()
    except OSError:  # 极长的路径 / 非法字符
        logger.warning("人格 %s 的 file 解析失败：%r", name, file_name)
        return None
    if path != PERSONAS_DIR.resolve() and PERSONAS_DIR.resolve() not in path.parents:
        logger.warning("人格 %s 的 file 越出了 personas/ 目录，已拒绝：%r", name, file_name)
        return None
    return path


# ======================================================================
# 读文件（fail-soft）
# ======================================================================

def load_persona_raw(name: str) -> str:
    """读人格提示词原文（**未清洗**）。读不到就返回空串，不抛。

    返回原文而不是清洗后的，是为了让 `/api/persona/{name}` 的预览能
    把「原文 / 清洗后」都摆出来 —— 不然「[reference] 到底清掉没有」
    没法当场验证。
    """
    if not str(name or "").strip():
        return ""
    path = persona_file_path(name)
    if path is None:
        return ""
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        logger.warning(
            "人格提示词文件不存在：%s（config.yaml 的 persona.%s.file 指向它）", path, name
        )
        return ""
    except OSError as exc:
        logger.warning("读人格提示词失败：%s（%s）", path, exc)
        return ""
    except UnicodeDecodeError as exc:
        # 编码坏了是最阴的一种：能读出字节、但全是乱码，链路全绿而模型行为诡异。
        # 多半是从别处拷文件时被按 ANSI 代码页转过一道。
        logger.warning("人格提示词不是 UTF-8：%s（%s）", path, exc)
        return ""
    return text


def clean_persona_text(text: str) -> str:
    """清掉 [reference:N] 之类的噪声标记。

    刻意**只**做这一件事：素材正文是 Markdown 排版的，用正则去剥 `#` / `**`
    又脆又可能破坏作者原意，那件事交给 `_BRIDGE` 的分隔语去交代。
    """
    return _REFERENCE_MARK.sub("", text).strip()


def load_persona_text(name: str) -> str:
    """读人格提示词并清洗。任何失败都返回空串（= 这个角色没有正文）。"""
    return clean_persona_text(load_persona_raw(name))


def bound_voice(name: str) -> str | None:
    """**配置里**这个人格绑定的 TTS 音色名；没绑就 None。

    ⚠ 名字刻意不叫 `resolve_persona_voice` —— runtime.py 里有一个同名同义的
    `resolve_persona_voice(引擎名)`，但它的参数是**引擎名**、返回的是
    「该引擎当前生效的人格音色覆盖」。两个同名函数一个收人格名、一个收引擎名，
    传错时不会报错、只会静默返回 None（页面上表现为音色莫名是空的）。
    """
    voice = str(_role_section(name).get("voice") or "").strip()
    return voice or None


# ======================================================================
# 组装 system prompt
# ======================================================================

def common_rules() -> str:
    """config.yaml 顶层 system_prompt —— **所有人格共用**的通用规则。

    它原本是「唯一的人设」，现在语义变成了「与身份无关的回答形式要求」。
    里头那几条是项目级的硬约束，不能因为换了人格就丢：
    回答要被朗读、所以不要 Markdown 和表情符号；以及图片附件的描述要求。
    """
    rules = load_config().get("system_prompt")
    return str(rules or "").strip()


def build_system_prompt(persona_name: str | None) -> str:
    """拼出最终发给模型的 system prompt。**保证不抛异常。**

    persona_name 为空 → 只返回通用规则（行为和加人格功能之前完全一样）。
    角色正文读不到 → 同样退化，只记一条 warning。

    顺序：**角色在前，通用规则在后**。让硬约束靠近生成位置更稳。
    """
    try:
        rules = common_rules()
        prompt = load_persona_text(persona_name or "")
    except Exception:  # noqa: BLE001 - 见模块开头：这里抛出去就是页面假死
        logger.exception("组装 system prompt 时出错，退化成只用通用规则")
        return ""

    if not prompt:
        # 没选角色，或者角色的正文读不到 —— 两种都退化成通用规则
        return rules
    if not rules:
        return prompt
    return f"{prompt}\n\n{_BRIDGE}\n{rules}"


def describe_persona(name: str) -> dict[str, Any]:
    """一个人格的可读信息，供 /api/options 和切换响应使用。**不抛异常。**

    `file_ok` 是「文件读不读得到」——把它暴露出去，是为了让「拷进来了
    但忘了加小节」「加了小节但忘了拷文件」这类问题**在页面上就能看见**，
    而不是等到对话时才发现角色没生效。
    """
    section = _role_section(name)
    text = load_persona_text(name) if section else ""
    path = persona_file_path(name) if section else None
    return {
        "name": str(name),
        "label": str(section.get("label") or name),
        "file": str(section.get("file") or ""),
        "voice": bound_voice(name),
        "file_ok": bool(text),
        "chars": len(text),
        "path": str(path) if path else None,
    }
