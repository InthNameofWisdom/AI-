"""弗洛洛对话 · 精简后端

从 ai-chat-demo 裁剪而来，只留对话主链路：

    WS  /ws           文字流 + 逐句语音 + 工具调用
    GET /api/options  设置面板数据源
    GET /api/switch   运行时切换（模型 / 引擎 / 音色 / 工具）
    GET /             单文件前端 index.html

去掉的：附件、SSE、/api/health、人格切换、提示词预览。

几个**不能动**的地方（都是原项目踩出来的坑，见各函数注释）：
  · index / buffer / saw_first_content 必须在工具轮次循环**外面**
  · tts_error 必须带着 index 发出去，否则前端永久卡住后面所有语音
  · provider.aclose() 之前必须先取消 worker
  · _build_messages 在 _run_turn 的 try 之外，绝对不能抛
  · include_router 必须在静态挂载之前
"""

from __future__ import annotations

import asyncio
import base64
import contextlib
import json
import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter, FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .config import PROJECT_ROOT, load_config, stale_config_hint
from .llm_provider import (
    LLMProviderError,
    ToolCall,
    create_provider,
    list_provider_instances,
)
from .persona import build_system_prompt, describe_persona, list_persona_names
from .runtime import (
    resolve_llm_name,
    resolve_persona_name,
    resolve_tools_enabled,
    resolve_tts_name,
    resolve_tts_voice,
    set_llm,
    set_tools,
    set_tts,
    set_tts_voice,
)
from .tools import (
    MAX_TOOL_CALLS_PER_ROUND,
    build_tool_definitions,
    execute_tool,
    get_tool,
    instance_tools_enabled,
    resolve_max_rounds,
)
from .tts_client import (
    StageDirectionStripper,
    TTSEngine,
    clean_for_tts,
    create_tts_engine,
    get_split_config,
    list_tts_engines,
    split_sentences,
)

logger = logging.getLogger(__name__)

INDEX_FILE = PROJECT_ROOT / "index.html"
ASSETS_DIR = PROJECT_ROOT / "assets"

MAX_HISTORY_MESSAGES = 20
VOICE_LIST_TIMEOUT = 12.0          # 拉音色列表的超时，别让 /api/options 卡住页面

app = FastAPI(title="frolova-chat", version="1.0")
api = APIRouter()


# ======================================================================
# 通用工具
# ======================================================================

async def _send_json(websocket: WebSocket, payload: dict[str, Any], lock: asyncio.Lock) -> None:
    """发一条 JSON 帧。

    必须加锁：文字 token 和音频块来自不同的并发协程，
    不加锁两次 send_text 会交错，前端收到半截 JSON 直接解析失败。
    """
    async with lock:
        await websocket.send_text(json.dumps(payload, ensure_ascii=False))


def _tool_detail(spec: Any, arguments: Any, result: str | None) -> str:
    """工具 chip 上那行短说明。result 为 None = 还在执行，此时显示参数。"""
    if spec is None:
        return ""
    if isinstance(arguments, dict):
        parsed = arguments
    else:
        try:
            parsed = json.loads(arguments or "{}")
        except (json.JSONDecodeError, TypeError):
            parsed = {}
        if not isinstance(parsed, dict):
            parsed = {}
    try:
        return spec.summarize(parsed, result)
    except Exception:  # noqa: BLE001 - 摘要挂掉不该拖垮对话
        logger.debug("工具 %s 的 summarize 出错", getattr(spec, "name", "?"), exc_info=True)
        return ""


def _build_messages(history: Any, user_message: str) -> list[dict[str, Any]]:
    """拼出要发给 LLM 的 messages。

    历史来自前端，属不可信输入 —— 只保留 role 合法的条目。

    ⚠ 这个函数在 _run_turn 的 try **之外**被调用，抛异常没人接：
    结果是整轮一个帧都发不出去、前端发送键永久变灰、只能刷新页面。
    所以这里包了一层，build_system_prompt() 自己也是 fail-soft 的。
    """
    try:
        system_prompt = build_system_prompt(resolve_persona_name())
    except Exception:  # noqa: BLE001
        logger.exception("组装 system prompt 失败，本轮退化成不带 system")
        system_prompt = ""

    messages: list[dict[str, Any]] = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})

    if not isinstance(history, list):
        history = []
    for item in history[-MAX_HISTORY_MESSAGES:]:
        if not isinstance(item, dict):
            continue
        role = item.get("role")
        if role not in ("user", "assistant"):
            continue
        content = item.get("content")
        if not isinstance(content, str) or not content.strip():
            continue
        messages.append({"role": role, "content": content.strip()})

    messages.append({"role": "user", "content": user_message})
    return messages


# ======================================================================
# TTS worker：并发预取
# ======================================================================

async def _send_tts(
    websocket: WebSocket,
    queue: asyncio.Queue[tuple[int, str]],
    engine: TTSEngine,
    send_lock: asyncio.Lock,
) -> None:
    """从队列取句子 → 合成 → base64 推给前端。

    单句失败只发一条 tts_error，不中断整轮 —— 前端会把这个 index
    标记成「跳过」，继续播后面的。**漏发这条消息会导致后面全部无声。**
    """
    while True:
        index, sentence = await queue.get()
        try:
            audio = await engine.synthesize(sentence)
            await _send_json(
                websocket,
                {
                    "type": "audio",
                    "index": index,
                    "text": sentence,
                    # 不能写死 wav：GPT-SoVITS 出 wav，Edge-TTS 出 mp3。
                    # 前端拿它拼 data:audio/<format>;base64,
                    "format": engine.audio_format,
                    "data": base64.b64encode(audio).decode("ascii"),
                },
                send_lock,
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            logger.warning("第 %d 句 TTS 合成失败：%s", index, exc)
            with contextlib.suppress(Exception):
                await _send_json(
                    websocket,
                    {
                        "type": "tts_error",
                        "index": index,
                        "text": sentence,
                        "message": str(exc),
                    },
                    send_lock,
                )
        finally:
            queue.task_done()


# ======================================================================
# 一轮对话
# ======================================================================

async def _run_turn(websocket: WebSocket, payload: dict[str, Any]) -> None:
    user_message = str(payload.get("message") or "").strip()
    if not user_message:
        await _send_json(
            websocket, {"type": "error", "message": "消息内容为空"}, asyncio.Lock()
        )
        return

    history = payload.get("history") or []
    send_lock = asyncio.Lock()

    delimiters, max_chars = get_split_config()
    queue_maxsize = max(1, int((load_config().get("tts") or {}).get("queue_maxsize", 20)))
    messages = _build_messages(history, user_message)

    try:
        provider = create_provider()
    except LLMProviderError as exc:
        await _send_json(websocket, {"type": "error", "message": str(exc)}, send_lock)
        return

    # TTS 引擎**每轮现建**（不是连接建立时建一次）—— 前端切完引擎，
    # 下一轮就生效，不用重连、不用重启。
    tts_engine: TTSEngine | None
    try:
        tts_engine = create_tts_engine()
    except Exception as exc:  # noqa: BLE001
        # 刻意不当成致命错误：语音挂了，文字也要照常输出完
        tts_engine = None
        await _send_json(websocket, {"type": "tts_unavailable", "message": str(exc)}, send_lock)

    sentence_queue: asyncio.Queue[tuple[int, str]] | None = None
    workers: list[asyncio.Task[None]] = []
    if tts_engine is not None:
        # 有界队列 = 背压，防止 LLM 远快于 TTS 时内存堆积
        sentence_queue = asyncio.Queue(maxsize=queue_maxsize)
        workers = [
            asyncio.create_task(_send_tts(websocket, sentence_queue, tts_engine, send_lock))
            for _ in range(max(1, tts_engine.concurrency))
        ]

    # 工具按实例开关：不同模型对 function calling 的支持差别很大，
    # 不支持的模型收到 tools 参数轻则忽略、重则直接报错
    tool_definitions: list[dict[str, Any]] = []
    if resolve_tools_enabled() and instance_tools_enabled(provider.name):
        tool_definitions = build_tool_definitions()
    max_rounds = resolve_max_rounds() if tool_definitions else 0

    # ⚠ 这三个必须在轮次循环**外面**：
    #   index  —— 每轮重置的话，第二轮音频的序号和前端 AudioSequencer
    #             已经走过的游标对不上，那些音频永远等不到自己的号 ——
    #             **整轮都不出声**，而且不报任何错。
    #   buffer —— 跨轮保留，才能把「北京今天」和「晴，24 度。」接成一句。
    #   saw_first_content —— typing 指示器是整轮语义，不是每轮。
    buffer = ""
    index = 0
    saw_first_content = False
    tool_ran = False
    round_messages = list(messages)
    # 括号动作描写不进语音。状态必须跨 token、跨工具轮次保留：
    # 一句动作描写常常比 max_chars 长，会被断句器切成好几段（见 tts_client 里的说明）
    stage_filter = StageDirectionStripper()

    try:
        for round_no in range(max_rounds + 1):
            # 每轮**重新赋值**而不是累加：写成 += 会把上一轮的工具再执行一遍，
            # 然后一路循环到 max_rounds 用完，全程不报错
            pending: list[ToolCall] = []

            async for event in provider.stream_events(
                round_messages, tools=tool_definitions or None
            ):
                if event.text:
                    if not saw_first_content:
                        saw_first_content = True
                        await _send_json(websocket, {"type": "first_token"}, send_lock)

                    await _send_json(
                        websocket, {"type": "text", "content": event.text}, send_lock
                    )

                    if sentence_queue is not None:
                        # 只用过滤后的文本拼 buffer；display 走的是 event.text，
                        # 所以动作描写照常显示在页面上，只是不会被朗读
                        buffer += stage_filter.feed(event.text)
                        ready, buffer = split_sentences(buffer, delimiters, max_chars)
                        for raw_sentence in ready:
                            cleaned = clean_for_tts(raw_sentence)
                            if not cleaned:
                                # 纯代码块/纯符号不值得合成。**不占 index** ——
                                # 没发出去的号前端不会等
                                continue
                            await sentence_queue.put((index, cleaned))
                            index += 1

                if event.done:
                    pending = list(event.tool_calls)

            if not pending:
                break

            # 轮次预算用完 —— 必须在执行工具**之前**判断，
            # 否则会白跑一次工具、还画出一个永远等不到答案的 chip
            if round_no >= max_rounds:
                logger.warning("工具调用轮次已达上限 %d，不再执行", max_rounds)
                await _send_json(
                    websocket,
                    {"type": "text", "content": "（工具调用轮次已达上限，就先回答到这里。）"},
                    send_lock,
                )
                break

            calls = pending[:MAX_TOOL_CALLS_PER_ROUND]
            # 有些本地服务不发 id 或发空串，会破坏 assistant 的 tool_calls
            # 与下面 role=tool 那条之间的配对。这里兜一个，两条消息共用
            call_ids = [
                call.id or f"call_{round_no}_{position}"
                for position, call in enumerate(calls)
            ]

            round_messages.append(
                {
                    "role": "assistant",
                    # content 用空串不用 None：部分 LM Studio 版本对 null 会报错
                    "content": "",
                    "tool_calls": [
                        {
                            "id": call_ids[position],
                            "type": "function",
                            "function": {"name": call.name, "arguments": call.arguments},
                        }
                        for position, call in enumerate(calls)
                    ],
                }
            )

            for position, call in enumerate(calls):
                spec = get_tool(call.name)
                label = spec.label if spec else call.name

                await _send_json(
                    websocket,
                    {
                        "type": "tool",
                        "name": call.name,
                        "label": label,
                        "status": "running",
                        "detail": _tool_detail(spec, call.arguments, None),
                    },
                    send_lock,
                )

                result = await execute_tool(call.name, call.arguments)
                tool_ran = True

                await _send_json(
                    websocket,
                    {
                        "type": "tool",
                        "name": call.name,
                        "label": label,
                        # 失败如实报：断网时 get_weather 每次都失败，
                        # 照样画绿色「完成」的话，坏工具和好工具长得一样
                        "status": "done" if result.ok else "error",
                        "detail": _tool_detail(spec, call.arguments, result.text),
                    },
                    send_lock,
                )

                round_messages.append(
                    {"role": "tool", "tool_call_id": call_ids[position], "content": result.text}
                )

        # 工具跑了但模型一个字没说：某些推理模型带 tools 时会把回答全塞进
        # reasoning_content，而 provider 只取 content（过滤内心独白是既定设计）。
        # 不说一句的话，界面上就是「一个 chip 之后没下文了」，像卡死
        if tool_ran and not saw_first_content:
            logger.warning("工具已执行，但模型没有产出任何 content —— 常见于推理模型带 tools 时")
            await _send_json(
                websocket,
                {"type": "text", "content": "（工具已经调用并拿到了结果，但模型没有给出文字回答。）"},
                send_lock,
            )

        if sentence_queue is not None:
            # 收尾：最后一句通常没有结束标点。只在所有轮次结束后冲一次，
            # 每轮都冲的话前半句会被用句号语调念出来，然后静默几秒
            tail = clean_for_tts(buffer)
            if tail:
                await sentence_queue.put((index, tail))
                index += 1

            # 等音频真正发完再宣告 done，否则前端会在语音还没播完时显示「生成结束」
            await sentence_queue.join()
        await _send_json(websocket, {"type": "done"}, send_lock)

    except asyncio.CancelledError:
        raise                      # 用户点了停止，由外层接收循环处理
    except LLMProviderError as exc:
        logger.warning("LLM 调用失败：%s", exc)
        await _send_json(websocket, {"type": "error", "message": str(exc)}, send_lock)
    except Exception as exc:  # noqa: BLE001
        logger.exception("处理对话时发生未预期错误")
        await _send_json(
            websocket, {"type": "error", "message": f"{type(exc).__name__}: {exc}"}, send_lock
        )
    finally:
        # ⚠ 顺序有意义：先取消 worker，再关客户端。反过来的话，
        # aclose() 抛出 BaseException 时下面几行永远执行不到，
        # worker 会永久挂在 queue.get() 上
        for worker in workers:
            worker.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
        with contextlib.suppress(Exception):
            await provider.aclose()
        if tts_engine is not None:
            with contextlib.suppress(Exception):
                await tts_engine.aclose()


# ======================================================================
# WebSocket
# ======================================================================

@api.websocket("/ws")
async def ws_chat(websocket: WebSocket) -> None:
    """对话入口。一条连接只有一个接收循环。

    生成放在独立 task 里，这样「停止生成」的帧才能在生成过程中被收到；
    在生成里再 await receive 的话两个协程读同一条连接会出问题。
    """
    await websocket.accept()

    current: asyncio.Task | None = None

    async def stop_current() -> None:
        nonlocal current
        if current is not None and not current.done():
            current.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await current
        current = None

    try:
        while True:
            raw = await websocket.receive_text()
            try:
                payload = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send_text(
                    json.dumps({"type": "error", "message": "消息不是合法 JSON"}, ensure_ascii=False)
                )
                continue
            if not isinstance(payload, dict):
                continue

            if payload.get("type") == "stop":
                was_running = current is not None and not current.done()
                await stop_current()
                if was_running:
                    await websocket.send_text(
                        json.dumps({"type": "done", "stopped": True}, ensure_ascii=False)
                    )
                continue

            # 上一轮还没跑完又发来一条：先收掉旧的，避免两个 task 抢同一条连接
            await stop_current()
            current = asyncio.create_task(_run_turn(websocket, payload))

    except WebSocketDisconnect:
        logger.info("客户端断开连接")
    except Exception:  # noqa: BLE001
        logger.exception("WebSocket 循环异常退出")
    finally:
        await stop_current()


# ======================================================================
# 设置面板：/api/options 与 /api/switch
# ======================================================================

async def _llm_options() -> dict[str, Any]:
    """所有 LLM 实例 + 当前是哪个。

    available 指的是「**配置**完整可用」（真构造一次 provider），
    不是「连不连得上」—— 缺 API Key、${VAR} 没解析出值这类问题
    能在打开面板时就暴露，而不是等发消息才报错。
    """
    cfg = load_config()
    items: list[dict[str, Any]] = []

    for name in list_provider_instances(cfg):
        section = (cfg.get("llm") or {}).get(name)
        section = section if isinstance(section, dict) else {}
        item: dict[str, Any] = {
            "name": name,
            "label": section.get("label") or name,
            "model": section.get("model"),
            "available": True,
            "error": None,
            "tools": bool(section.get("tools")),
        }
        try:
            provider = create_provider(name)
        except Exception as exc:  # noqa: BLE001
            item["available"] = False
            item["error"] = str(exc)
        else:
            with contextlib.suppress(Exception):
                await provider.aclose()
        items.append(item)

    return {"current": resolve_llm_name(), "instances": items}


async def _fetch_voices() -> dict[str, Any]:
    """问一次当前 TTS 引擎：当前用的音色 + 服务器上有哪些可选。

    raw 是服务器原样给的列表（用来判断某个音色存不存在）；
    ui 是给下拉框用的，会把「配置里的当前音色」补进去免得下拉框空着。
    只拉一次 —— options 里两处要用，拉两次服务器没起来时白等两倍超时。
    尽力而为，拿不到就返回空 + 原因，不抛。
    """
    result: dict[str, Any] = {
        "current_voice": None, "raw": [], "ui": [], "error": None,
        "hosts_persona_voices": False,
    }
    engine = None
    try:
        engine = create_tts_engine()
        result["current_voice"] = engine.model_name
        result["hosts_persona_voices"] = engine.hosts_persona_voices
        raw = list(await asyncio.wait_for(engine.list_voices(), timeout=VOICE_LIST_TIMEOUT))
        result["raw"] = raw
        current = result["current_voice"]
        result["ui"] = [current, *raw] if (current and raw and current not in raw) else raw
    except Exception as exc:  # noqa: BLE001
        result["error"] = str(exc)
    finally:
        if engine is not None:
            with contextlib.suppress(Exception):
                await engine.aclose()
    return result


async def _tts_options(voices_info: dict[str, Any]) -> dict[str, Any]:
    cfg = load_config()
    tts_cfg = cfg.get("tts") or {}
    items: list[dict[str, Any]] = []

    for name in list_tts_engines():
        raw = tts_cfg.get(name)
        raw = raw if isinstance(raw, dict) else {}
        item: dict[str, Any] = {
            "name": name,
            "label": raw.get("label") or name,
            "type": raw.get("type") or name,
            "format": raw.get("media_type"),
            "concurrency": raw.get("concurrency"),
            "available": True,
            "error": None,
        }
        try:
            engine = create_tts_engine(name)
        except Exception as exc:  # noqa: BLE001
            # 构造失败也保留配置里的静态信息，下拉框至少显示个像样的名字
            item["available"] = False
            item["error"] = str(exc)
        else:
            item["label"] = engine.label or name
            item["type"] = engine.name
            item["format"] = engine.audio_format
            item["concurrency"] = engine.concurrency
            with contextlib.suppress(Exception):
                await engine.aclose()
        items.append(item)

    return {
        "current": resolve_tts_name(),
        "current_voice": voices_info.get("current_voice"),
        "voices": voices_info.get("ui") or [],
        "voice_error": voices_info.get("error"),
        "engines": items,
    }


def _persona_info(voices_info: dict[str, Any]) -> dict[str, Any]:
    """人格信息（这里只有一个弗洛洛，不在页面上切换）。

    voice_found 是**三态**，None = 判不了，不是 False：
      · 人格没绑音色 / 音色列表没拉到      → None
      · 当前引擎不承载角色音色（Edge-TTS） → None
        ⚠ 这一条最容易漏：Edge 有自己的十来个音色，拿它的列表去比角色音色，
          会得出「音色名有误」—— 但那不是配置错，只是这套音色不属于它。
          而这个判断是 GPT-SoVITS **静默失败**唯一能事先发现的地方，用错就废了。
      · 列表里有这个名字                  → True
      · 列表里没有                        → False（这时才该报「音色名有误」）
    """
    raw = voices_info.get("raw") or []
    fetch_error = voices_info.get("error")
    hosts = bool(voices_info.get("hosts_persona_voices"))
    names = list_persona_names()
    item = describe_persona(names[0]) if names else {}
    voice = item.get("voice")
    if not voice or fetch_error or not raw or not hosts:
        item["voice_found"] = None
    else:
        item["voice_found"] = voice in raw
    return {"current": resolve_persona_name(), "personas": [item] if names else []}


@api.get("/api/options")
async def options() -> JSONResponse:
    """设置面板数据源：有哪些可选、当前是哪个、哪些不可用及原因。"""
    voices_info = await _fetch_voices()
    return JSONResponse(
        {
            "llm": await _llm_options(),
            "tts": await _tts_options(voices_info),
            "persona": _persona_info(voices_info),
            "tools": {
                "enabled": resolve_tools_enabled(),
                "available": [d["function"]["name"] for d in build_tool_definitions()],
                "max_rounds": resolve_max_rounds(),
            },
            "config_stale": stale_config_hint(),
        }
    )


@api.post("/api/switch")
async def switch(payload: dict[str, Any]) -> JSONResponse:
    """运行时切换。只影响**下一轮**对话（引擎在 _run_turn 开头才建）。

    校验方式是「真构造一次」，不可用的一律 400 拒绝。
    """
    if not isinstance(payload, dict):
        return JSONResponse({"error": "请求体必须是 JSON 对象"}, status_code=400)

    result: dict[str, Any] = {"ok": True}

    if "llm" in payload:
        raw = payload.get("llm")
        if raw is None:
            set_llm(None)
        else:
            name = str(raw)
            provider = None
            try:
                provider = create_provider(name)
            except Exception as exc:  # noqa: BLE001
                return JSONResponse(
                    {"error": f"切到 LLM 实例 {name!r} 失败：{exc}"}, status_code=400
                )
            finally:
                if provider is not None:
                    with contextlib.suppress(Exception):
                        await provider.aclose()
            set_llm(name)
        result["llm"] = resolve_llm_name()

    if "tts" in payload:
        raw = payload.get("tts")
        if raw is None:
            set_tts(None)
        else:
            name = str(raw)
            engine = None
            try:
                engine = create_tts_engine(name)
            except Exception as exc:  # noqa: BLE001
                return JSONResponse(
                    {"error": f"切到 TTS 引擎 {name!r} 失败：{exc}"}, status_code=400
                )
            finally:
                if engine is not None:
                    with contextlib.suppress(Exception):
                        await engine.aclose()
            set_tts(name)
        result["tts"] = resolve_tts_name()

    if "voice" in payload:
        raw = payload.get("voice")
        engine_name = resolve_tts_name()

        if raw is None:
            set_tts_voice(engine_name, None)       # 回到配置里的默认音色
        else:
            voice = str(raw).strip()
            if not voice:
                return JSONResponse({"error": "音色名不能为空"}, status_code=400)

            engine = None
            try:
                engine = create_tts_engine()
                # 用服务器给的列表校验，而不是真合成一句（那要好几秒）。
                # 这步不能省：服务器对坏音色名是**静默失败**的
                # （返回空 audio_url，不报错），不校验就会选到一个
                # 永远没声音、还不知道为什么的选项
                available = await asyncio.wait_for(
                    engine.list_voices(), timeout=VOICE_LIST_TIMEOUT
                )
                if available and voice not in available:
                    return JSONResponse(
                        {
                            "error": (
                                f"音色 {voice!r} 不在引擎 {engine_name!r} 的可用列表里。\n"
                                f"  可用音色：{'、'.join(available[:10])}"
                            )
                        },
                        status_code=400,
                    )
            except asyncio.TimeoutError:
                return JSONResponse(
                    {
                        "error": (
                            f"拉取音色列表超时（{VOICE_LIST_TIMEOUT:.0f} 秒）—— "
                            "TTS 服务器是不是没起来？"
                        )
                    },
                    status_code=400,
                )
            except Exception as exc:  # noqa: BLE001
                # 列表拿不到就没法校验，放行 —— 真正合成时的 tts_error
                # 会把问题报出来，那条链路是完整的
                logger.warning("校验音色 %r 时拿不到列表，跳过校验：%s", voice, exc)
            finally:
                if engine is not None:
                    with contextlib.suppress(Exception):
                        await engine.aclose()

            set_tts_voice(engine_name, voice)

        result["voice"] = resolve_tts_voice(engine_name)

    if "tools" in payload:
        raw = payload.get("tools")
        # None 是「清除覆盖、回配置文件」，False 是「显式关掉」——两者不同
        set_tools(None if raw is None else bool(raw))
        result["tools"] = resolve_tools_enabled()

    logger.info(
        "运行时切换：llm=%s tts=%s voice=%s tools=%s",
        result.get("llm"), result.get("tts"), result.get("voice"), result.get("tools"),
    )
    return JSONResponse(result)


# ======================================================================
# 静态前端
# ======================================================================

@api.get("/")
async def index() -> Any:
    if not INDEX_FILE.is_file():
        return JSONResponse(
            {"error": "找不到 index.html", "detail": f"期望位置：{INDEX_FILE}"},
            status_code=503,
        )
    return FileResponse(INDEX_FILE, media_type="text/html")


@api.get("/favicon.ico")
async def favicon() -> Any:
    icon = ASSETS_DIR / "frolova-icon.png"
    if icon.is_file():
        return FileResponse(icon, media_type="image/png")
    return JSONResponse({}, status_code=404)


def mount_frontend(fastapi_app: FastAPI) -> None:
    """挂 assets 目录。

    ⚠ 必须在 include_router() **之后**调用。挂载如果盖住路由，
    症状是 /api/* 返回 HTML 404 而服务端一点报错都没有。
    这里刻意只挂 /assets 而不是把项目根目录整个挂出去 ——
    根目录下有 .env 和 config.yaml，挂出去等于把密钥暴露在 HTTP 上。
    """
    if ASSETS_DIR.is_dir():
        fastapi_app.mount("/assets", StaticFiles(directory=str(ASSETS_DIR)), name="assets")
        logger.info("静态资源目录：%s", ASSETS_DIR)
    else:
        logger.warning("没有 assets 目录（页面会用纯 CSS 主题，不影响使用）")


def apply_persona_voice() -> None:
    """把配置里的人格音色灌进 runtime 的人格音色层。

    原项目是在 /api/switch 的 persona 分支里做的，这里没有那个人格切换，
    所以启动时直接应用一次 —— 否则 persona.phrolova.voice 就成了死配置，
    音色只认 tts 段的 model_name。两者现在都写着弗洛洛_ZH，
    但改音色时应该只改一处（persona 段）。

    失败不影响启动：音色会落回 tts 段配置的那个。
    """
    try:
        from .persona import bound_voice
        from .runtime import set_persona_voice

        voice = bound_voice(resolve_persona_name())
        if voice:
            set_persona_voice(resolve_tts_name(), voice)
            logger.info("人格音色已应用：%s", voice)
    except Exception:  # noqa: BLE001
        logger.warning("应用人格音色失败，将使用 tts 段配置的音色", exc_info=True)


app.include_router(api)
mount_frontend(app)
apply_persona_voice()


if __name__ == "__main__":
    import uvicorn

    # 只有这里设置 logging —— 不设的话 persona / tools 里的
    # logger.warning 全是静默的
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    server_cfg = load_config().get("server") or {}
    host = str(server_cfg.get("host", "0.0.0.0"))
    port = int(server_cfg.get("port", 8770))

    logger.info("启动后端：http://localhost:%d", port)
    uvicorn.run(app, host=host, port=port)
