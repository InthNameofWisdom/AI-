# -*- coding: utf-8 -*-
"""
配置加载
========
读取项目根目录的 config.yaml，并把其中的 ${VAR} 替换成环境变量值。

为什么要单独一个模块：llm_provider / tts_client / main 都要读配置，
分散在三处各写一遍会因为「谁先 .env 加载」而出现难查的时序 bug。
统一在这里 load_dotenv()，其它模块只管 load_config()。
"""
from __future__ import annotations

import os
import re
import time
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = PROJECT_ROOT / "config.yaml"
ENV_PATH = PROJECT_ROOT / ".env"

# load_config() 第一次执行（也就是缓存建立）的时刻。
# 用来判断「配置文件是不是在那之后又被改过」—— 见 stale_config_hint()。
_cached_at: float = 0.0

# 支持 ${VAR} 和 ${VAR:-默认值} 两种写法
_ENV_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}")


def _expand(value: str) -> str:
    """把字符串里的 ${VAR} 换成环境变量值；变量不存在时替换为空串。

    替换成空串而不是抛异常，是为了让 create_provider() / create_tts_engine()
    能统一做一处校验并给出「请检查 .env」这类可读的错误提示。
    """

    def repl(match: re.Match[str]) -> str:
        name, default = match.group(1), match.group(2)
        if name in os.environ:
            return os.environ[name]
        return default if default is not None else ""

    return _ENV_PATTERN.sub(repl, value)


def _walk(node: Any) -> Any:
    """递归地把配置树里所有字符串都做一次环境变量替换。"""
    if isinstance(node, dict):
        return {k: _walk(v) for k, v in node.items()}
    if isinstance(node, list):
        return [_walk(v) for v in node]
    if isinstance(node, str):
        return _expand(node)
    return node


@lru_cache(maxsize=1)
def load_config() -> dict[str, Any]:
    """加载并缓存 config.yaml。

    结果是缓存的 —— 改了 config.yaml 或 .env 需要重启后端才生效
    （这也正是演示里「改配置 → 重启 → 换 provider」的步骤）。
    忘了重启时的症状很隐蔽：前端的下拉框里那一项一直是灰的，
    所以另有 stale_config_hint() 专门检测这种情况。
    """
    global _cached_at
    _cached_at = time.time()

    load_dotenv(ENV_PATH, override=False)

    if not CONFIG_PATH.exists():
        raise FileNotFoundError(f"找不到配置文件：{CONFIG_PATH}")

    with CONFIG_PATH.open(encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    return _walk(raw)


def stale_config_hint() -> str | None:
    """配置文件在进程读完之后又被改过 → 提示需要重启。

    这个提示是为了堵一个很容易踩的坑：
    改了 .env（比如补上 API Key）却忘了重启后端，于是前端下拉框里
    那一项一直是灰的、点不动，而页面上没有任何东西解释为什么 ——
    看起来就像「功能坏了」，而不是「配置没生效」。

    lru_cache 是刻意的设计（配置不该每轮对话都重读磁盘），
    所以这里不去偷偷清缓存，只如实报告「你改的东西还没生效」。
    """
    if not _cached_at:
        return None

    changed: list[str] = []
    for path in (CONFIG_PATH, ENV_PATH):
        try:
            mtime = path.stat().st_mtime
        except OSError:
            continue
        # 给 1 秒容差，免得文件系统和进程时钟的细微差别造成误报
        if mtime > _cached_at + 1.0:
            changed.append(path.name)

    if not changed:
        return None

    names = "、".join(changed)
    return (
        f"{names} 在后端启动之后被修改过，但配置是缓存的 —— 改动还没有生效。\n"
        "  -> 重启后端即可（关掉后端窗口再跑一次 run.bat）\n"
        "  -> 注意：用页面上的设置面板切换模型/引擎**不需要**重启，"
        "只有改 .env / config.yaml 才需要"
    )


# .env.example 里出现这些字样就认为还是模板里的占位符，不是用户填的真值
_PLACEHOLDER_MARKERS = ("xxx", "your", "changeme", "placeholder", "example", "填入", "<", ">")


def _parse_env_file(path: Path) -> dict[str, str]:
    """极简 .env 解析：只认 `KEY=value`，跳过注释和空行。

    不追求完备（引号、多行值、`export` 前缀都不管）——
    这里只是用来帮用户排查「值填错文件了」，宁可漏报也不要误报。
    """
    out: dict[str, str] = {}
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return out

    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        if key:
            out[key] = value.strip().strip('"').strip("'")
    return out


def _looks_like_placeholder(value: str) -> bool:
    low = value.lower()
    return any(marker in low for marker in _PLACEHOLDER_MARKERS)


def _looks_like_secret(value: str) -> bool:
    """粗判一个值像不像真实密钥。

    刻意排除地址和短串 —— 那些在 .env.example 里本来就是文档示例，
    报出来只会是误报。宁可漏报，不要误报。
    """
    if len(value) < 16 or _looks_like_placeholder(value):
        return False
    if "://" in value:  # URL
        return False
    if re.fullmatch(r"[\d.\-:/]+", value):  # 100.64.1.5、127.0.0.1:1234 之类
        return False
    return True


def env_example_hint() -> str | None:
    """检测一个特别常见的手误：把真实密钥填进了 .env.example。

    这个文件长得太像「该填的地方」了 —— 名字里就带着 env。
    但程序**只读 .env**，填在那里完全无效；更糟的是
    .env 在 .gitignore 里、.env.example 却**会进 git**，
    等于把密钥提交上去了。

    判定条件：某个变量在 .env.example 里是「像真密钥」的值，
    但在环境里是空的。两边都空、或环境里已经有了，都不算问题。

    返回的提示已经带好两格缩进，可以直接接在别的错误信息后面。
    """
    example = PROJECT_ROOT / ".env.example"
    if not example.exists():
        return None

    suspects = [
        key
        for key, value in _parse_env_file(example).items()
        if _looks_like_secret(value) and not os.environ.get(key, "").strip()
    ]
    if not suspects:
        return None

    listed = "、".join(suspects)
    return (
        f"  [-] 另外发现：{listed} 在 .env.example 里填了看起来是真的值\n"
        f"      · .env.example 只是**模板**，程序只读 .env，从来不读它 —— 填在那里等于没填\n"
        f"      · 请把那几行挪到 .env（没有 .env 就先从 .env.example 复制一份再改）\n"
        f"      · 而且 .env.example 是**会进 git** 的，真实密钥不要留在里面"
    )


def missing_env_hint(text: str, field: str) -> str | None:
    """检查替换后的字符串是否留下了「值没填」的痕迹，返回可读的错误提示。

    ${LMSTUDIO_HOST} 未设置时会变成 "http://:1234/v1"，
    ${DEEPSEEK_API_KEY} 未设置时会变成空串 —— 这两种情况都要提前拦住，
    否则报出来的会是 openai SDK 里难以理解的连接错误。
    """
    if "://:" in text or text.endswith("://"):
        message = (
            f"{field} 里的环境变量没有解析出值：{text!r}\n"
            f"  -> 请确认项目根目录存在 .env，且里面填了对应的变量"
            f"（可从 .env.example 复制）"
        )
        extra = env_example_hint()
        return f"{message}\n{extra}" if extra else message
    return None
