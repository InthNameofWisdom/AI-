# -*- coding: utf-8 -*-
"""
LLM Provider 抽象 + 工厂
========================
同一套业务代码，通过 config.yaml 的 llm.provider 字段在多个模型服务之间切换：

    deepseek           DeepSeek 云端
    lmstudio_local     本机 LM Studio（第二台电脑）
    lmstudio_remote    第一台电脑的 LM Studio（经 Tailscale 跨网）

核心结论（来自 test_deepseek-learning/lesson02）：
    这些服务提供的都是 OpenAI 兼容协议 —— 请求体结构、响应结构完全一致，
    只有「地址、模型名、密钥」三处不同。
    所以**一个实现类就够**，不需要为每一台机器写一个类。

配置采用的是「命名实例 + type」：

    llm:
      provider: lmstudio_local     # 选哪个实例
      lmstudio_local:
        type: openai_compatible    # 这个实例用哪种实现

想接第三台机器、或者 Ollama / vLLM？
    -> 在 config.yaml 里复制一段、改个名字和地址就行，Python 代码零改动。
想接一个协议不一样的（比如 Anthropic Messages API）？
    -> 写个类继承 LLMProvider，打上 @register_provider_type("xxx")，
       再在配置里把 type 写成 xxx。工厂会自动认出来。
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, AsyncGenerator, Callable, TypeVar

import httpx
from openai import AsyncOpenAI

from .config import env_example_hint, load_config, missing_env_hint
from .runtime import resolve_llm_name

logger = logging.getLogger(__name__)

T = TypeVar("T", bound="LLMProvider")


class LLMProviderError(RuntimeError):
    """provider 配置或调用出错。"""


# ======================================================================
# 流式事件
# ======================================================================

@dataclass(frozen=True)
class ToolCall:
    """模型要求调用的一次工具。参数是**原始 JSON 字符串**，没解析过。"""

    id: str
    name: str
    #: 模型生成的 JSON 字符串。⚠ 它**不保证合法**，见 backend/tools.py 的说明
    arguments: str


@dataclass(frozen=True)
class LLMEvent:
    """流式响应里的一小块。

    为什么要从「yield 字符串」改成这个：工具调用的参数**绝不能**当成正文。
    整条下游链路是「provider 吐出来的每个字符串 → 分句 → 送 TTS 朗读」，
    只要有人把 tool_calls 拼成字符串 yield 出去，观众就会听到模型朗读 JSON。
    改成类型化字段之后，参数在类型上就**进不了** text，
    而下游只有 text 会被送给 TTS —— 这个保证是结构性的，不靠自觉。

    字段：
      text       —— 要显示、也要朗读的正文
      tool_calls —— 模型要求调用的工具。**只在 done 事件里非空**
      done       —— 本轮流结束。每个 stream_events() 调用**恰好**产出一次，
                    且是最后一个。消费方靠它判断「这一轮模型到底要不要调工具」。
    """

    text: str = ""
    tool_calls: tuple[ToolCall, ...] = ()
    done: bool = False


# ======================================================================
# 实现类注册表
# ======================================================================

_PROVIDER_TYPES: dict[str, type["LLMProvider"]] = {}


def register_provider_type(type_name: str) -> Callable[[type[T]], type[T]]:
    """把一个 LLMProvider 子类注册到工厂里，供 config.yaml 的 type 字段引用。"""

    def decorator(cls: type[T]) -> type[T]:
        if type_name in _PROVIDER_TYPES:
            raise ValueError(f"provider type {type_name!r} 已经注册过了")
        _PROVIDER_TYPES[type_name] = cls
        return cls

    return decorator


def available_types() -> list[str]:
    """当前支持哪些 type，报错时列给用户看。"""
    return sorted(_PROVIDER_TYPES)


# ======================================================================
# 抽象层
# ======================================================================

class LLMProvider(ABC):
    """LLM 提供商抽象基类。"""

    #: 供日志 / 前端展示的可读名字
    name: str = "unknown"
    #: 前端徽章上显示的标签
    label: str = ""
    #: 实际请求的地址，供自检接口展示
    base_url: str = ""
    #: 实际请求的模型名
    model: str = ""
    #: 调用这个 provider 需要的密钥（用于自检时探测连通性）
    api_key: str = ""

    @abstractmethod
    async def stream_events(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> AsyncGenerator[LLMEvent, None]:
        """流式对话：逐块产出 LLMEvent。

        ⚠ 实现方必须保证：**要展示、要被朗读的正文只能放进 `text`**，
        思考过程（reasoning_content）要丢弃，工具调用参数只能放 `tool_calls`。
        这条约束是整个项目里最重要的安全边界之一 —— 下游会把 `text`
        原样送去合成语音，混进去什么，用户就会听到什么。

        契约：
          · 正文逐块 yield，`text` 非空、`done=False`
          · 每个调用**恰好** yield 一次 `done=True` 的事件，且必须是最后一个
          · `tools` 为 None / 空 时表示这一轮不提供工具，实现方可以不传该参数

        :param tools: OpenAI 协议的 tools 定义，见 backend/tools.py
        """
        if False:  # pragma: no cover - 让函数成为生成器，同时保持抽象
            yield LLMEvent()
        raise NotImplementedError

    async def stream_chat(
        self, messages: list[dict[str, Any]]
    ) -> AsyncGenerator[str, None]:
        """兼容层：只要正文。

        **签名和语义与加工具之前完全一致**，所以 SSE 接口等既有调用方一行都不用改。
        它被定义在 `stream_events()` 之上，是单向的 —— 不存在两者各说各话的可能。
        新增 provider 只需要实现 `stream_events()`。
        """
        async for event in self.stream_events(messages):
            if event.text:
                yield event.text

    async def list_models(self) -> list[str]:
        """尽力列出可用模型；不支持就返回空列表（用于自检，不参与主流程）。"""
        return []

    async def aclose(self) -> None:
        """释放底层连接。默认什么都不做。"""
        return None


# ======================================================================
# OpenAI 兼容实现（目前所有实例都用它）
# ======================================================================

@register_provider_type("openai_compatible")
class OpenAICompatibleProvider(LLMProvider):
    """OpenAI 兼容协议的 provider。

    DeepSeek、LM Studio（本机 / 远程）、vLLM、Ollama 的兼容层……
    全都走这一个类。
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        model: str,
        temperature: float = 0.7,
        name: str = "openai_compatible",
        label: str = "",
        **extra_params: Any,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key or "not-needed"
        self.model = model
        self.temperature = temperature
        self.name = name
        self.label = label or name
        self.extra_params = extra_params
        self._client = AsyncOpenAI(base_url=self.base_url, api_key=self.api_key)

    async def stream_events(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> AsyncGenerator[LLMEvent, None]:
        # 只有真的传了工具才带这两个参数：某些服务收到空的 tools 数组会直接报错
        tool_kwargs: dict[str, Any] = {}
        if tools:
            tool_kwargs["tools"] = tools
            # tool_choice="auto" 让模型自己决定调不调工具。
            # **不要改成 "required"** —— 那会逼它每轮都必须调一个，
            # 连「你好」都要先查一次天气。
            tool_kwargs["tool_choice"] = "auto"

        try:
            stream = await self._client.chat.completions.create(
                model=self.model,
                messages=messages,  # type: ignore[arg-type]
                temperature=self.temperature,
                stream=True,
                **tool_kwargs,
                **self.extra_params,
            )
        except Exception as exc:  # noqa: BLE001 - 统一转成可读错误抛给前端
            raise LLMProviderError(
                f"调用「{self.label}」（{self.model} @ {self.base_url}）失败：{exc}"
            ) from exc

        # 工具调用是**分片**流过来的，按 index 分槽累积。详见下面的注释
        partial: dict[int, dict[str, str]] = {}

        async for chunk in stream:
            if not chunk.choices:
                # 某些服务会在流末尾发一个只带 usage 的空 choices 块
                continue
            delta = chunk.choices[0].delta
            if delta is None:
                continue

            # ------------------------------------------------------------------
            # 关键：只取 delta.content，显式忽略 delta.reasoning_content。
            #
            # DeepSeek v4 系列、Qwen3 等都是推理模型，流式响应里 content 之前会
            # 先流出 reasoning_content（模型的思考过程）。
            # 实测 qwen/qwen3.5-9b 前 200 个 chunk 全是 reasoning_content、
            # 一个 content 都没有。如果不过滤：
            #   1. 前端会把模型的内心独白当成正文显示出来
            #   2. 更糟的是，这段思考会被分句送进 TTS —— 用户会听到模型
            #      「自言自语」一大段，演示直接翻车
            #   3. 「首 token 已到达」的标记也会被提前触发，typing 指示器失效
            #
            # reasoning_content 在 SDK 里落在 delta.model_extra 上，
            # 我们只读 content，天然就把它挡在外面。
            # ------------------------------------------------------------------
            content = getattr(delta, "content", None)
            if content:
                # 整个 provider 里**只有这一处**产出 text。
                # 工具调用的参数走下面的 tool_calls，不在这条路径上，
                # 所以下游「text → 分句 → TTS 朗读」的链路天然碰不到它们。
                yield LLMEvent(text=content)

            # ------------------------------------------------------------------
            # 工具调用分片累积。
            #
            # 一次工具调用在流里会被拆成很多片，形如：
            #   {"index":0,"id":"call_abc","function":{"name":"get_weather","arguments":""}}
            #   {"index":0,                "function":{"arguments":"{\"ci"}}
            #   {"index":0,                "function":{"arguments":"ty\":\"北京\"}"}}
            #
            # ⚠ 三个必须留意的点：
            #   1. id 和 name **只在第一片**里出现，后续片是 None。
            #      所以必须写成 `if frag.id:` 而不是直接赋值 —— 无条件覆盖的话，
            #      name 会被后面那些 None 抹成空串，然后 execute_tool 收到一个
            #      空工具名，报「没有这个工具」。这是个很难查的静默失败。
            #   2. arguments 必须**拼接**，不能覆盖。
            #   3. 模型可能一口气要求调多个工具（index 0/1/2…），所以按 index 分槽。
            # ------------------------------------------------------------------
            for frag in getattr(delta, "tool_calls", None) or []:
                slot = partial.setdefault(frag.index, {"id": "", "name": "", "arguments": ""})
                if frag.id:
                    slot["id"] = frag.id
                function = getattr(frag, "function", None)
                if function is not None:
                    if function.name:
                        slot["name"] = function.name
                    if function.arguments:
                        slot["arguments"] += function.arguments

        # 流结束，统一发**一个** done 事件 —— 这是唯一携带 tool_calls 的地方。
        # 消费方因此可以简单地「每个 done 事件重新赋值一次 pending」，
        # 而不会把上一轮的工具调用又执行一遍（那会变成无限循环且无人察觉）。
        calls = tuple(
            ToolCall(
                # 有些本地服务不发 id。空 id 会破坏 assistant/tool 消息的配对，
                # 回灌结果时服务端会报错，所以这里补一个
                id=partial[index]["id"] or f"call_{index}",
                name=partial[index]["name"],
                arguments=partial[index]["arguments"] or "{}",
            )
            for index in sorted(partial)
        )
        yield LLMEvent(tool_calls=calls, done=True)

    async def list_models(self) -> list[str]:
        """GET {base_url}/models —— 自检时确认连通性和模型名。"""
        headers = {"Authorization": f"Bearer {self.api_key}"}
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(f"{self.base_url}/models", headers=headers)
            resp.raise_for_status()
            data = resp.json()
        items = data.get("data") if isinstance(data, dict) else None
        if isinstance(items, list):
            return [str(m.get("id")) for m in items if isinstance(m, dict) and m.get("id")]
        return []

    async def aclose(self) -> None:
        try:
            await self._client.close()
        except Exception:  # noqa: BLE001 - 关闭失败不该影响主流程
            logger.debug("关闭 OpenAI 客户端时出错", exc_info=True)


# ======================================================================
# 工厂
# ======================================================================

def _resolve_section(cfg: dict[str, Any], name: str) -> dict[str, Any]:
    llm_cfg = cfg.get("llm") or {}
    section = llm_cfg.get(name)
    if not isinstance(section, dict) or not section:
        known = list_provider_instances(cfg)
        raise LLMProviderError(
            f"config.yaml 里找不到 provider 实例 {name!r}。\n"
            f"  当前已定义的实例：{', '.join(known) if known else '（无）'}"
        )
    return section


def create_provider(name: str | None = None) -> LLMProvider:
    """工厂：按 config.yaml 创建一个 provider 实例。

    :param name: 指定用哪个实例（如 "lmstudio_remote"）。None 则用运行时
                 切换层的当前值，再回退到 config.yaml 的 llm.provider。

    优先级由 runtime.resolve_llm_name() 统一决定 —— 这里是热切换的**唯一**接入点，
    配置读取本身完全没动。
    """
    cfg = load_config()

    instance = (name or resolve_llm_name() or "").strip()
    if not instance:
        raise LLMProviderError("config.yaml 里没有设置 llm.provider")

    section = _resolve_section(cfg, instance)

    # type 缺省为 openai_compatible —— 兼容不带 type 的老写法
    type_name = str(section.get("type") or "openai_compatible").strip()
    cls = _PROVIDER_TYPES.get(type_name)
    if cls is None:
        raise LLMProviderError(
            f"provider 实例 {instance!r} 的 type={type_name!r} 没有对应的实现。\n"
            f"  当前支持的 type：{', '.join(available_types())}"
        )

    base_url = str(section.get("base_url") or "")
    hint = missing_env_hint(base_url, f"llm.{instance}.base_url")
    if hint:
        raise LLMProviderError(hint)

    api_key = str(section.get("api_key") or "")
    if not api_key:
        message = (
            f"llm.{instance}.api_key 是空的。\n"
            "  -> 如果你在配置里写的是 ${XXX} 形式，请确认 .env 里填了 XXX\n"
            "  -> 本地服务随便填个占位符即可（例如 lm-studio）"
        )
        # 最常见的失败原因就是把密钥填进了 .env.example —— 主动看一眼
        example_hint = env_example_hint()
        if example_hint:
            message = f"{message}\n{example_hint}"
        raise LLMProviderError(message)

    model = section.get("model")
    if not model:
        raise LLMProviderError(f"config.yaml 里没有设置 llm.{instance}.model")

    # 把 type/model/temperature/api_key/base_url/label 之外的字段当作额外参数透传。
    #
    # ⚠ "tools" 必须留在保留集合里。它是**我们自己的开关**
    # （见 backend/tools.py 的 instance_tools_enabled），不是 OpenAI 的请求参数。
    # 漏掉的话它会被塞进 extra_params，最后变成 create(tools=True) ——
    # 一个布尔值被当成工具定义列表发出去，该实例的**每一次**请求都会 400，
    # 而且报错信息完全指不到配置上。
    reserved = {"type", "base_url", "api_key", "model", "temperature", "label", "tools"}
    extra = {k: v for k, v in section.items() if k not in reserved}

    if extra:
        # 未知字段会被原样透传给 SDK。写错一个字母（比如 enable_tools）没有任何人提示，
        # 只会在每次对话时报一个看不懂的错 —— 所以至少在这里留下痕迹
        logger.info("llm.%s 里这些字段会被透传给 SDK：%s", instance, sorted(extra))

    logger.info("已创建 LLM provider 实例：%s（type=%s, model=%s）", instance, type_name, model)
    return cls(
        base_url=base_url,
        api_key=api_key,
        model=str(model),
        temperature=float(section.get("temperature", 0.7)),
        name=instance,
        label=str(section.get("label") or instance),
        **extra,
    )


def list_provider_instances(cfg: dict[str, Any] | None = None) -> list[str]:
    """config.yaml 里定义了哪些 provider 实例（排除 provider 这个标量键）。"""
    llm_cfg = (cfg or load_config()).get("llm") or {}
    return sorted(k for k, v in llm_cfg.items() if isinstance(v, dict))


def describe_provider(name: str | None = None) -> dict[str, Any]:
    """返回当前 provider 的可读信息，供 /api/health 自检接口展示。

    这个函数**不做校验**，配置有问题时也要能返回信息 —— 否则自检接口
    自己就 500 了，看不到任何线索。

    注意这里也必须走 resolve_llm_name()：热切换之后 health 报的实例名
    要和 create_provider() 实际用的那个一致，否则自检结果会骗人。
    """
    cfg = load_config()
    llm_cfg = cfg.get("llm") or {}
    instance = (name or resolve_llm_name() or "").strip()
    section = llm_cfg.get(instance) if instance else None
    section = section if isinstance(section, dict) else {}

    return {
        "instance": instance,
        "type": section.get("type") or "openai_compatible",
        "label": section.get("label") or instance,
        "model": section.get("model"),
        "base_url": section.get("base_url"),
        "available": list_provider_instances(cfg),
    }
