/* 用 Node 跑 index.html 里的真实自检代码（验证完就删）
 *
 * Edge 的 headless 在这台机器上不出输出，所以改成：
 * 把内联 <script> 抽出来，配一套最小 DOM 桩，直接执行 —— 跑的是
 * **文件里真实的代码**，不是抄一份。重点覆盖音频顺序和会话校验
 * 这两块「回归了也不会报错、只会静默失效」的逻辑。
 *
 *   node _selftest_node.js
 */
const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
const m = html.match(/<script>([\s\S]*?)<\/script>/);
if (!m) { console.error('没找到内联 script'); process.exit(1); }

/* ---------- 最小 DOM 桩 ---------- */
function makeNode(tag = 'div') {
  const node = {
    tagName: tag, children: [], dataset: {}, style: {},
    className: '', textContent: '', innerHTML: '', value: '', checked: false,
    disabled: false, title: '', src: '', alt: '', scrollTop: 0, scrollHeight: 0, clientHeight: 0,
    classList: {
      _set: new Set(),
      add(...c) { c.forEach((x) => this._set.add(x)); },
      remove(...c) { c.forEach((x) => this._set.delete(x)); },
      toggle(c, force) { const on = force === undefined ? !this._set.has(c) : force; if (on) this._set.add(c); else this._set.delete(c); return on; },
      contains(c) { return this._set.has(c); },
    },
    appendChild(child) { this.children.push(child); child.parentNode = this; return child; },
    insertBefore(child) { this.children.push(child); child.parentNode = this; return child; },
    remove() { if (this.parentNode) this.parentNode.children = this.parentNode.children.filter((c) => c !== this); },
    replaceWith(next) { if (this.parentNode) this.parentNode.children = this.parentNode.children.map((c) => (c === this ? next : c)); },
    replaceChildren() {},
    querySelector() { return null; },
    querySelectorAll() { return []; },
    addEventListener() {}, removeEventListener() {}, focus() {}, select() {}, load() {},
    removeAttribute() {}, setAttribute() {},
    get childElementCount() { return this.children.length; },
    get firstChild() { return this.children[0] || null; },
  };
  // innerHTML 赋值时清掉子节点，够用
  Object.defineProperty(node, 'innerHTML', {
    get() { return this._html || ''; },
    set(v) { this._html = String(v); this.children = []; },
  });
  return node;
}
const nodes = new Map();
const document = {
  title: 'frolova',
  getElementById(id) { if (!nodes.has(id)) nodes.set(id, makeNode()); return nodes.get(id); },
  createElement: (tag) => makeNode(tag),
  addEventListener() {}, removeEventListener() {},
  querySelector() { return null; },
  body: makeNode('body'),
};
const storage = new Map();
globalThis.document = document;
globalThis.location = { protocol: 'http:', host: '127.0.0.1:8770', search: '?selftest=1', href: 'http://127.0.0.1:8770/?selftest=1' };
globalThis.localStorage = {
  getItem: (k) => (storage.has(k) ? storage.get(k) : null),
  setItem: (k, v) => storage.set(k, String(v)),
  removeItem: (k) => storage.delete(k),
};
globalThis.requestAnimationFrame = (fn) => setTimeout(fn, 0);
globalThis.fetch = () => Promise.reject(new Error('no network in this test'));
globalThis.WebSocket = function () { throw new Error('不需要连 WS'); };
globalThis.Audio = function () { return { play: () => Promise.resolve() }; };
globalThis.URLSearchParams = URLSearchParams;

/* ---------- 执行真实脚本 ---------- */
const logs = [];
const realTable = console.table;
console.table = (rows) => { rows.forEach((r) => logs.push(r)); };
try {
  (0, eval)(m[1]);
} catch (exc) {
  console.error('执行脚本时抛异常：', exc);
  process.exit(1);
}
console.table = realTable;

/* ---------- 结果 ---------- */
if (!logs.length) { console.error('自检没有产出任何用例（?selftest 分支没跑到？）'); process.exit(1); }
let failed = 0;
for (const r of logs) {
  if (!r.ok) failed += 1;
  console.log(`${r.ok ? '  ✓' : '  ✗'} ${r.name}${r.ok ? '' : '   ' + (r.extra || '')}`);
}
console.log('');
console.log(`document.title = ${document.title}`);
console.log(failed ? `==== 失败 ${failed} / ${logs.length} 项 ====` : `==== 全部通过（${logs.length} 项）====`);
process.exit(failed ? 1 : 0);
