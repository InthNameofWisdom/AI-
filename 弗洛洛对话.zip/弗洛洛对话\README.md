# 弗洛洛对话

一个单页面的对话程序：打字 → 模型流式回答 → 按标点分句送语音合成 → 前端按顺序播放。
人格固定为《鸣潮》的弗洛洛，前端是**一个 `index.html`**，没有 npm、没有构建步骤。

## 跑起来

```bat
run.bat                  :: 建 venv（首次）→ 起后端 → 打开浏览器
run.bat --check-only     :: 只做检查，不起服务
run.bat --no-browser     :: 起服务，但不开浏览器
```

首次运行会自动建 venv 并装依赖（几分钟，需要联网），之后直接起后端。
端口从 `config.yaml` 的 `server.port` 读（默认 **8770**），改了配置这里也跟着变。

想让它有声音，先把这两个服务开着（都不开也能跑，页面上会说明哪些不可用）：

| 服务 | 端口 | 用途 |
|---|---|---|
| GPT-SoVITS | 8000 | 本地语音合成，音色 `弗洛洛_ZH` |
| LM Studio | 1234 | 本地模型，默认 `google/gemma-4-e4b` |

没有 GPT-SoVITS 也能试整条链路：`python tts_server_mock.py`，再把 `config.yaml` 里
`tts.gptsovits.base_url` 指向假服务。

## 环境变量

`copy .env.example .env` 之后填这两项（不填也能跑，只是对应选项在面板里是灰的）：

```
DEEPSEEK_API_KEY=sk-...           # 云端模型
LMSTUDIO_HOST_REMOTE=100.64.x.x   # 另一台电脑的 LM Studio（Tailscale）
```

## 移植到别的电脑

整个目录拷过去就能跑，**但别把 `venv/` 拷过去**：

| | 内容 |
|---|---|
| ✅ 要拷 | `backend/`、`personas/`、`assets/`、`index.html`、`config.yaml`、`requirements.txt`、`run.bat`、`README.md` |
| ❌ 不要拷 | `venv/`（里面记录着创建它的 Python 的**绝对路径**，换台机器必然起不来）、`__pycache__/` |
| 看情况 | `.env`（见下的警告）、`tts_server_mock.py`、几个 `_*.py` / `_*.js` 验证脚本 |

目标机器上**只需要 Python 3.10+**（本机验证的是 3.14.7；`run.bat` 会直接拒绝更老的版本，
也会认出来 Microsoft Store 那个假 python）。不需要 Node、不需要 npm、不需要构建。
双击 `run.bat`，它会自己建 venv、装依赖、查端口、起后端、开浏览器。

**换机器后第一件该改的事**：`config.yaml` 里的 `llm.provider`。
默认是 `lmstudio_local`（要那台机器上跑着 LM Studio）。新机器上没装 LM Studio 的话，
把它改成 `deepseek` 并填好 `.env` —— **面板里切换只存在内存里，重启就回到配置文件的默认值**，
不改配置的话每次开都要手动切一次模型。

**拷错的容错**：就算真的把 `venv/` 一起拷过去了也不会坏 —— `run.bat` 会先拿它试跑一次
Python，失败就删掉重建。没有这一步的话，表现是「窗口一闪就没了」，很难查。

⚠ **`.env` 里有你的 `DEEPSEEK_API_KEY`（真实密钥）**。拷给别人之前先删掉它，让对方从
`.env.example` 自己填。`.gitignore` 已经排除它，但直接拷文件夹不受 git 管。

⚠ **`personas/弗洛洛.txt` 是中文文件名**。用 zip / U 盘 / 网盘传的时候，编码没处理好的话
文件名会变成乱码，`config.yaml` 里的 `file:` 就对不上了 —— 后果是**角色提示词静默失效**，
弗洛洛变成普通助手。`run.bat` 启动时会检查这一点并提示；设置面板里那行也会写成
「⚠ 读不到提示词文件」。实在怕出问题就把文件改成 ASCII 名（如 `phrolova.txt`），
同时改 `config.yaml` 里 `persona.phrolova.file` 那一行。

**什么都不装的裸机也能起来**：页面照常打开、设置面板会如实写明哪些不可用，
发消息会返回连接失败（本地模型/语音都不在）。

⚠ 面板里那个「可用」指的是**配置是否完整**，不是「服务连不连得上」——
所以没装 LM Studio 的机器上，`lmstudio_local` 仍然显示为可用，发消息才会报连接失败。
（这是刻意取舍：每次打开面板都去 ping 三个实例太慢。原来的项目用 `/api/health` 做连通性
自检，这个精简版把它去掉了。）

想让它真正能用，三条路：

1. 装 GPT-SoVITS（8000）—— 有语音，音色克隆的 `弗洛洛_ZH`
2. 装 LM Studio（1234）—— 有本地模型，不花钱不联网
3. 只填 `.env` 里的 `DEEPSEEK_API_KEY` —— 云端模型，不用装任何本地服务

## 页面上能做什么

- **流式文字**：token 边生成边显示，首 token 到达时撤掉 typing 指示器
- **逐句语音**：后端并发合成、前端按编号还原顺序；某一句合成失败只跳过那一句
- **括号里的动作描写只显示、不朗读**：`（我垂下眼帘，指尖轻触着彼岸花。）`
  这类文字是给眼睛看的，念出来会打断语气。它仍然显示在页面上，
  但合成前会被整段去掉 —— 一次回复里这类描写常常占掉一半的语音段数
- **而且默认就要求它别叙述动作**：`config.yaml` 的 `system_prompt` 里写明了
  「不要叙述自己的动作、神态或心理活动」（括号和句子两种写法都点了名）。
  这是主要手段，上面那个过滤器只是兜底 —— 模型换一种不用括号的写法时，
  过滤器是拦不住的。想要舞台感（会写动作描写）就把那段话删掉，
  语音会自动跳过括号部分（⚠ 改 `system_prompt` 要重启后端）
- **多会话**：左侧列表，自动命名、重命名、删除，存 localStorage
- **工具调用**：模型自己决定去查算数 / 时间 / 天气，页面上有 chip 显示状态
- **设置面板**：模型 / 语音引擎 / 音色 / 工具开关，**下一轮生效**，不用重启也不用刷新

改 `personas/弗洛洛.txt`（角色提示词）**不用重启**，下一轮就生效。
改 `config.yaml` / `.env` 要重启。

## 目录

```
backend/       main.py 是新写的精简版；其余 6 个模块从 ai-chat-demo 原样拷过来
personas/      弗洛洛的提示词正文
assets/        弗洛洛的官方美术（见下）
index.html     整个前端（约 1500 行，含 CSS）
_smoke.py      后端冒烟：真跑一轮，断言音频序号连续、工具参数不串进正文
_app_test.js   前端集成：用 jsdom 在真 DOM 里跑，断言渲染 / 播放顺序 / 落盘
_selftest_node.js  跑 index.html 里的自检用例（音频顺序 + 会话校验）
```

后几个是排查用的脚本，不用可以删。改完代码想确认没坏：

```bat
venv\Scripts\python.exe _smoke.py      :: 后端：真跑一轮 + 各种边界
node _selftest_node.js                 :: 顺序控制器 + 会话校验（零依赖）
```

前两个**零依赖**，随便哪台机器都能跑。下面这两个在真 DOM 里跑整个页面，
需要 jsdom（本项目自己不需要 npm，开发机上借的是同级 ai-chat-demo 的 node_modules）：

```bat
set NODE_PATH=..\ai-chat-demo\frontend\node_modules
node _app_test.js        :: 35 项断言
node _e2e_live.js        :: 端到端：真页面 ↔ 真后端 ↔ 真模型 ↔ 真语音
```

换台电脑没有 jsdom 也不影响使用 —— 脚本会提示替代方案，或者浏览器里打开页面加
`?selftest=1`，页面内自检 12 项。

## 图片

`assets/` 里三张都是《鸣潮》/库洛游戏的官方美术，取自萌娘百科，**仅供本地自用，不要公开发布**：

| 文件 | 用途 |
|---|---|
| `frolova-icon.png` | 顶栏头像、助手头像、favicon |
| `frolova-full.png` | 空状态立绘 |
| `frolova-wash.jpg` | 背景氛围（重度模糊，只取色彩） |

图删了页面照样能用：头像会退化成内联的彼岸花 SVG，背景只是少一层。

## 和 ai-chat-demo 的关系

从社团面试那个项目裁剪而来，但**它一行都没改**，只当拷贝来源。这边去掉的：
附件（图片 / 文本文件）、SSE 接口、`/api/health`、人格切换、提示词预览、自检脚本。

后端 `main.py` 是新写的；`config.py` / `runtime.py` / `persona.py` / `llm_provider.py` /
`tts_client.py` / `tools.py` 是原样拷贝 —— 它们互相耦合（`llm_provider` 和 `tts_client`
都依赖 `runtime`），裁剪的收益不如风险。

**`tts_client.py` 是唯一改过的拷贝**，三处：

| 改动 | 为什么 |
|---|---|
| 新增 `StageDirectionStripper` | 括号动作描写不进语音（见上）。必须跨 token 保留括号深度 —— 描写常比 `max_chars` 长，会被断句器切成好几段，单句正则救不了 |
| `clean_for_tts()` 里加了一条括号规则 | 兜住「括号不跨句」的简单情况 |
| `TTSEngine.hosts_persona_voices` | 让「这台引擎承不承载角色音色」有地方声明。切到 Edge-TTS 时人格音色不再被误报成「音色名有误」 |
